%% sub-national HDI

clc
clear
close all
    
cd /Volumes/Kummu_GIS/matlab/global_RBV/
addpath(genpath('/Volumes/Kummu_GIS/matlab/global_RBV/'));

%% load data

% spatial extent files created in prepare_data_gdp_hdi.m
load hdi_spatial_extent.mat

% NUTS, in EU (all subnational areas has ID less than 1000)
temp_macro_hdi = hdi_subnat_all_cut;
temp_macro_hdi(temp_macro_hdi>1000) = 0;
M_nuts_id = temp_macro_hdi;

% other areas, outside EU (all subnational areas has ID more than 1000)
temp_macro_hdi = hdi_subnat_all_cut;
temp_macro_hdi(temp_macro_hdi<1000) = 0;

M_subnat_id = temp_macro_hdi;

clearvars temp_hdi


%% read sub-national data

% sub-national databases
subnat_hdi = xlsread('/Users/mkummu/Documents/work/publications/varis_al_global_RBV/hdi/adm1_gis_layer_v3_to_qgis.xlsx','adm1_gis_layer_v3','A2:I568');

% we needed to modify the id in GIS analysis; here 1000 added
subnat_hdi(:,1) = 1000 + subnat_hdi(:,1);

% nuts (EU)
nuts_hdi = xlsread('/Users/mkummu/Documents/work/publications/varis_al_global_RBV/hdi/nuts2_hdi_matlab.xlsx','nuts2_HDI','C2:F361');

%% read country data

% fao_id - compatible with the adm0_5min 
% HDI - human development index - the higher the better

[~,~, raw_country] = xlsread('/Volumes/Kummu_GIS/matlab/global_RBV/socio_indicators_hdi_1990_2015.xlsx','HDI_to_matlab'); %we only want the raw data

temp_national_hdi = raw_country(2:end,3:end); %get rid of text rows and columns
national_hdi = cell2mat(temp_national_hdi); %convert numbers stored as text to numeric data
clearvars temp_national_hdi

national_hdi(national_hdi == 0) = NaN;

clearvars temp* raw*

%% Macro-regional areas

%% calculate regional average

% go through the years where data is available
macroreg_hdi = unique(national_hdi(:,2));

% identify countries with full dataset
temp_national_hdi = national_hdi;

% remove rows if even one NaN
temp_national_hdi(any(isnan(temp_national_hdi(:,3:end)), 2),:)=[];

% collect [TBA]
for i = 1:size(temp_national_hdi,2)-2    
    temp = accumarray(temp_national_hdi(:,2),temp_national_hdi(:,i+2),[],@nanmean);
    macroreg_hdi(1:12,i+1) = temp(:,1);    
end

% no data to NaN
macroreg_hdi(macroreg_hdi == 0) = NaN;

clearvars temp*
clearvars i j 


%% read HDI based on old method to calculate the index (this data is used for scaling the regional values, as data available to all countries but West Sahara)

[~,~, raw_country] = xlsread('/Volumes/Kummu_GIS/matlab/global_RBV/socio_indicators_hdi_1990_2014.xlsx','HDI_old_method','I7:M227'); %we only want the raw data

temp_national_hdi = raw_country(2:end,3:end); %get rid of text rows and columns
national_hdi_old_method = cell2mat(temp_national_hdi); %convert numbers stored as text to numeric data
clearvars temp_national_hdi

national_hdi_old_method(national_hdi_old_method == 0) = NaN;

% find the countries with full data on full dataset
for i = 1:size(national_hdi,1)
    temp = national_hdi(i,3:end);
    temp_hdi_count(i,1) = sum(temp(:) > 0);
end

[row,col] = find(temp_hdi_count == nanmax(temp_hdi_count));

% calculate macro-regional average based on old HDI method -data

macroreg_hdi_old_method = unique(national_hdi(:,2));

national_hdi_old_method_sel = national_hdi_old_method(row,:);
    
temp = accumarray(national_hdi_old_method_sel(:,2),national_hdi_old_method_sel(:,3),[],@nanmean);
macroreg_hdi_old_method(1:12,2) = temp(:,1);

% no data to NaN
macroreg_hdi_old_method(macroreg_hdi_old_method == 0) = NaN;

% scaling factor to all countries
for i = 1:size(national_hdi_old_method,1)
    temp_regio_id = national_hdi_old_method(i,2);
    if isnan(national_hdi_old_method(i,3)) % for three countries no data was found, for these, we use regional value
        national_hdi_old_method(i,5) = 1;
    else
    national_hdi_old_method(i,5) = national_hdi_old_method(i,3) ./ macroreg_hdi_old_method(temp_regio_id,2);
    end
end

clear row col i temp* raw* *_sel

%% fill NaN rows in national_hdi with scaled macro-regional averages

national_hdi_filled = national_hdi;

temp_national_hdi = national_hdi;

% remove all rows with some numbers
temp_national_hdi(any(~isnan(temp_national_hdi(:,3:end)), 2),:)=[];

% collect country codes wihtout any data
cntry_code_no_data = temp_national_hdi(:,1:2);

% for these countries, use scaled macro-regional values
for j = 1:size(temp_national_hdi,1)
    temp_cntry_id = temp_national_hdi(j,1);
    
    [row,col] = find(national_hdi_filled(:,1) == temp_cntry_id);
    
    national_hdi_filled(row,3:end) = national_hdi_old_method(row,5) .* macroreg_hdi(temp_national_hdi(j,2),2:end);
    
end

clearvars temp* i j

%% interpolation of national values

national_hdi_interp = zeros(size(national_hdi_filled));
national_hdi_interp(:,1:2) = national_hdi_filled(:,1:2);

for i = 1:size(national_hdi_filled,1) % go through each country
    temp = national_hdi_filled(i,3:end);
    
    % use inpaint_nans function to interpolate missing values
    temp_interp = inpaint_nans(temp,3);
    
    national_hdi_interp(i,3:end) = temp_interp;
end

clearvars temp* i


%% detect the cells that should be extrapolated

% years to be extrapolated at the beginning of the study period
national_hdi_extrapol_start = zeros(size(national_hdi_filled));
national_hdi_extrapol_start(:,1:2) = national_hdi_filled(:,1:2);

for i = 1:size(national_hdi_filled,1)
    temp = national_hdi_filled(i,3:end);
    for k = 1:size(temp,2)
        temp_check = temp(1,1:k);
        temp_check(~any(~isnan(temp_check), 2),:) = -1; 
        temp_result(1,k) = temp_check(1,k);
    end
    
    national_hdi_extrapol_start(i,3:end) = temp_result;
end
clearvars temp* i k

% years to be extrapolated at the end of the study period
national_hdi_extrapol_end = zeros(size(national_hdi_filled));
national_hdi_extrapol_end(:,1:2) = national_hdi_filled(:,1:2);


for i = 1:size(national_hdi_filled,1)
    temp = fliplr(national_hdi_filled(i,3:end)); % flip the dataset to make it easier to find cells that needed to be extrapolated
    for k = 1:size(temp,2)
        temp_check = temp(1,1:k);
        temp_check(~any(~isnan(temp_check), 2),:) = -1;
        temp_result(1,k) = temp_check(1,k);
    end
    
    national_hdi_extrapol_end(i,3:end) = fliplr(temp_result); % flip back
end

clearvars temp* i k
%% extrapolate

national_hdi_extrapol = zeros(size(national_hdi_filled));
national_hdi_extrapol(:,1:2) = national_hdi_filled(:,1:2);

% the years at end of the study period
for i = 1:size(national_hdi_filled,1)
    temp_macro_area = national_hdi_filled(i,2);
    
    [row,col] = find(national_hdi_extrapol_end(i,3:end) == -1);
    
    if isempty(col)  % nothing will happen
        
    elseif size(col,2) == 26 % in case no data at all
        
    else
                
        [row_meta,col_meta] = find(macroreg_hdi(:,1) == temp_macro_area); % find correct macro-region
                    
        temp_macro_hdi = macroreg_hdi(row_meta,(col(1,1)-1:end)); % select value
        
        temp_national_last_entry = national_hdi_interp(i,col(1,1)+1); % detect the last available national value
        temp_diff = temp_national_last_entry ./ temp_macro_hdi(1,1);  % calculate the difference between the regional value and the last available national value
        
        % use the temporal trend from macro region to estimate the missing
        % national value, scaled with the difference calculated above
        temp_national_hdi_2015 = temp_diff .* temp_macro_hdi(1,3:end);
        
        % fill the matrix
        national_hdi_extrapol(i,col(1,1)+2:end) = temp_national_hdi_2015;
    end
end
clearvars temp* i k


% the first years
for i = 1:size(national_hdi_filled,1)
    temp_macro_area = national_hdi_filled(i,2);
    
    [row,col] = find(fliplr(national_hdi_extrapol_start(i,3:end)) == -1); % flip timeseries around, to make it easier to estimate the missing values
    
    if isempty(col) % in case no need to extrapolate
        
    elseif size(col,2) == 26 % in case no data at all
        
        
    else
                
        [row_meta,col_meta] = find(macroreg_hdi(:,1) == temp_macro_area); % find correct macro-region
                
        % flip  
        temp_macro_hdi = fliplr(macroreg_hdi(row_meta,2:end));
        
        temp_macro_hdi = temp_macro_hdi(1,(col(1,1)-1:end));
        
        
        temp_nat_hdi = fliplr(national_hdi_interp(i,3:end));
        
        temp_nat_last_entry = temp_nat_hdi(1,col(1,1)-1); % detect the last available national value
        temp_diff = temp_nat_last_entry ./ temp_macro_hdi(1,1); % calculate the difference between the regional value and the last available national value
        
        % use the temporal trend from macro region to estimate the missing
        % national value, scaled with the difference calculated above
        temp_national_hdi_2015 = temp_diff .* temp_macro_hdi(1,2:end);
        
        % fill the matrix
        national_hdi_extrapol(i,3:3+size(col,2)-1) = fliplr(temp_national_hdi_2015);
    end
end
clearvars temp* i k col* row* 

%% combine interpolated and extrapolated data

national_hdi_filled_final = zeros(size(national_hdi_filled));
national_hdi_filled_final(:,1:2) = national_hdi_filled(:,1:2);

national_hdi_filled_final(:,3:end) = national_hdi_interp(:,3:end);

temp_filled = national_hdi_extrapol(:,:);

% fill the values from extrapolated dataset to the one that was
% interpolated
national_hdi_filled_final(temp_filled > 0) = temp_filled(temp_filled > 0);

clearvars temp*

%% distance to closest reported value - for error calculations

% interpolation
temp_interp = national_hdi;
temp_interp(national_hdi_extrapol_start == -1) = -1;

% extrapolation
temp_extrap = national_hdi_extrapol_start;

% missing values
% for those where no data, extrapolation from year 2009 backwards and
% onwards
for i = 1:size(cntry_code_no_data,1)
    temp_id = cntry_code_no_data(i,1);
    [row,col] = find(national_hdi(:,1) == temp_id);
    
    temp_extrap(row,[3:21 23:end]) = -1;
    temp_extrap(row,[3:21 23:end]) = -1;
end

temp_extrap(isnan(temp_extrap)) = -1;

temp = temp_extrap(:,3:end);
temp(temp>-1) = NaN;

temp_extrap(:,3:end) = temp;

% count the distance to closest available value with bwdist function
temp_extrap_count = temp_extrap;
temp_extrap_count(temp_extrap_count == -1) = 0;
temp_extrap_count(isnan(temp_extrap_count)) = 1;

extrap_count = temp_extrap;

for i = 1:size(temp_extrap,1)
    extrap_count(i,3:end) = bwdist(temp_extrap_count(i,3:end));   
end

clear temp* row col i ans



%% cntry data to raster

adm0_5min = hdi_cntry_all;

adm0_5min(adm0_5min == adm0_5min(1,1)) = NaN;
imagesc(adm0_5min);

M_national_hdi = zeros(size(adm0_5min,1),size(adm0_5min,2),size(national_hdi_filled_final,2)-2,'single');
M_extrap_dist = zeros(size(adm0_5min,1),size(adm0_5min,2),size(national_hdi_filled_final,2)-2,'single');

temp_cntry_id = unique(adm0_5min);
temp_cntry_id(temp_cntry_id < 0) = [];


for yr = 1:size(M_national_hdi,3)
    
    temp = zeros(size(adm0_5min)); % create empty map
    temp_distance = zeros(size(adm0_5min)); % create empty map
    
    for i = 1:size(temp_cntry_id,1)
        temp_cntry_logical = adm0_5min == temp_cntry_id(i,1); % create a mask for a country in question
        
        [r,c] = find(national_hdi_filled_final(:,1) == temp_cntry_id(i,1)); % find correct data
        if isempty(r)
            %stop
        else
            temp(temp_cntry_logical) = national_hdi_filled_final(r,yr+2); % fill the cells of that country with the HDI value
            M_national_hdi(:,:,yr) = M_national_hdi(:,:,yr) + temp; % put that to the final raster map
            temp = zeros(size(adm0_5min)); % empty the temp map
            
            temp_distance(temp_cntry_logical) = extrap_count(r,yr+2); % fill the cells of that country with the 'distance' value
            M_extrap_dist(:,:,yr) = M_extrap_dist(:,:,yr) + temp_distance; % put that to the final raster map
            temp_distance = zeros(size(adm0_5min)); % empty the temp map
            
        end
        
    end
end
clearvars i k r c temp*


figure;

    imagesc(M_extrap_dist(:,:,2)); % check that ok
    
    colorbar
  
save hdi_distance_to_closest_value.mat extrap_count M_extrap_dist % to be used in accuracy estimates
%% sub-national analysis

% load historical population maps
load('/Volumes/Kummu_GIS/datasets/hyde_3_2/pop_hyde_32.mat');

% select the map for population for year 2010
pop_2010 = pop_hyde_32(:,:,21);
clearvars pop_h*

% nuts

for i = 1:size(nuts_hdi,1)
    temp_nuts_logical = M_nuts_id == nuts_hdi(i,2); % create a mask for the NUTS (sub-national unit in EU) in question
    
    temp_pop = temp_nuts_logical .* pop_2010; % use the mask to population dataset
    
    nuts_hdi(i,5) = nansum(nansum(temp_pop)); % calculate the population of that NUTS 
    
end

% pop weighted HDI
nuts_hdi(:,6) = nuts_hdi(:,5) .* nuts_hdi(:,3);

% cntry scale
nuts_hdi_cntry = accumarray(nuts_hdi(:,1),nuts_hdi(:,1),[],@nanmean); % cntry ID for the first column
nuts_hdi_cntry(:,2) = accumarray(nuts_hdi(:,1),nuts_hdi(:,5),[],@nansum); % aggregate population for each country
nuts_hdi_cntry(:,3) = accumarray(nuts_hdi(:,1),nuts_hdi(:,6),[],@nansum); % aggregate population * HDI for each country
% hdi
nuts_hdi_cntry(:,4) = nuts_hdi_cntry(:,3) ./ nuts_hdi_cntry(:,2); % calculate the population weighted HDI for each country

for i = 1:size(nuts_hdi,1)
    temp_cntry_id = nuts_hdi(i,1);
    
    [row,col] = find(nuts_hdi_cntry(:,1) == temp_cntry_id);
    temp_cntry_hdi = nuts_hdi_cntry(row,4);
    
    nuts_hdi(i,7) = temp_cntry_hdi; % national average HDI for each NUTS unit

end

% NUTS hdi ratio to national average

nuts_hdi(:,8) = nuts_hdi(:,3)./nuts_hdi(:,7); % how much HDI in each NUTS differes from national average


% subnational areas outside EU

for i = 1:size(subnat_hdi,1)
    temp_subnat_logical = M_subnat_id == subnat_hdi(i,1);
    
    temp_pop = temp_subnat_logical .* pop_2010;
    
    subnat_hdi(i,10) = nansum(nansum(temp_pop));
    
end

% pop weighted HDI
subnat_hdi(:,11) = subnat_hdi(:,10) .* subnat_hdi(:,9);

% cntry scale
subnat_hdi_cntry = accumarray(subnat_hdi(:,2),subnat_hdi(:,2),[],@nanmean); % cntry ID for the first column
subnat_hdi_cntry(:,2) = accumarray(subnat_hdi(:,2),subnat_hdi(:,10),[],@nansum); % aggregate population for each country
subnat_hdi_cntry(:,3) = accumarray(subnat_hdi(:,2),subnat_hdi(:,11),[],@nansum); % aggregate population * HDI for each country
% hdi
subnat_hdi_cntry(:,4) = subnat_hdi_cntry(:,3) ./ subnat_hdi_cntry(:,2); % calculate the population weighted HDI for each country

for i = 1:size(subnat_hdi,1)
    temp_cntry_id = subnat_hdi(i,2);
    
    [row,col] = find(subnat_hdi_cntry(:,1) == temp_cntry_id);
    temp_cntry_hdi = subnat_hdi_cntry(row,4);
    
    subnat_hdi(i,12) = temp_cntry_hdi; % national average HDI for each sub-national unit

end

% sub-national hdi ratio to national average

subnat_hdi(:,13) = subnat_hdi(:,9)./subnat_hdi(:,12); % how much HDI in each sbu-national unit differes from national average

clearvars temp*

%% HDI ratios to map

M_nuts_hdi_ratio = zeros(size(adm0_5min,1),size(adm0_5min,2),1,'single');

temp_nuts_id = unique(M_nuts_id);
temp_nuts_id(temp_nuts_id < 0) = [];

temp = zeros(size(adm0_5min));

for i = 1:size(temp_nuts_id,1)
    temp_nuts_logical = M_nuts_id == temp_nuts_id(i,1); % create mask to a given NUTS area
    
        [r,c] = find(nuts_hdi(:,2) == temp_nuts_id(i,1)); % find the value from data matrix
        if isempty(r)
        %stop
        else       
        temp(temp_nuts_logical) = nuts_hdi(r,8); % put that value to the mask
        M_nuts_hdi_ratio(:,:,1) = M_nuts_hdi_ratio(:,:,1) + temp; % add the value to the whole map
        temp = zeros(size(adm0_5min));
        end
    
end

M_nuts_hdi_ratio(M_nuts_hdi_ratio == 0) = NaN;
imagesc(M_nuts_hdi_ratio)

M_subnat_hdi_ratio = zeros(size(adm0_5min,1),size(adm0_5min,2),1,'single');

temp_subnat_id = unique(M_subnat_id);
temp_subnat_id(temp_subnat_id < 0) = [];

temp = zeros(size(adm0_5min));

for i = 1:size(temp_subnat_id,1)
    temp_subnat_logical = M_subnat_id == temp_subnat_id(i,1); % create mask to a given sub-national area
    
        [r,c] = find(subnat_hdi(:,1) == temp_subnat_id(i,1)); % find the value from data matrix
        if isempty(r)
        %stop
        else       
        temp(temp_subnat_logical) = subnat_hdi(r,13); % put that value to the mask
        M_subnat_hdi_ratio(:,:,1) = M_subnat_hdi_ratio(:,:,1) + temp; % add the value to the whole map
        temp = zeros(size(adm0_5min));
        end
    
end

M_subnat_hdi_ratio(M_subnat_hdi_ratio == 0) = NaN;

imagesc(M_subnat_hdi_ratio);

clearvars temp*

%% combine ratio maps

M_subnat_hdi_ratio(isnan(M_subnat_hdi_ratio)) = 0;
% create mask for reg_hdi
mask_reg_hdi = M_subnat_hdi_ratio > 0;

M_nuts_hdi_ratio(isnan(M_nuts_hdi_ratio)) = 0;
% to avoid double counting, put all cells zero where there is value for
% reg_hdi
M_nuts_hdi_ratio(mask_reg_hdi) = 0;

M_hdi_ratio = M_subnat_hdi_ratio + M_nuts_hdi_ratio;

imagesc(M_hdi_ratio); % check that all ok
%% final HDI

M_hdi_final = zeros(size(M_national_hdi),'single');

mask_regions = M_hdi_ratio > 0; % create mask to the areas to which sub-national value is available

for yr = 1:size(M_national_hdi,3)
    
    temp_subnat = M_hdi_ratio.*M_national_hdi(:,:,yr); % use the ratio map to calculate final HDI value using national HDI map
    
    
    temp_national = M_national_hdi(:,:,yr);
    temp_national(mask_regions) = 0; % put HDI to zero to all areas to which sub-national data is available
    
    M_hdi_final(:,:,yr) = temp_national + temp_subnat;
    
end

% limit to 1
M_hdi_final(M_hdi_final>1) = 1; % in cases where sub-national value get value more than 1 (due to very high ratio), limit it to 1

% sea to NaN
sea = land == 0;
M_hdi_final(repmat(sea,1,1,size(M_hdi_final,3))) = NaN;


imagesc(M_hdi_final(:,:,10));

%% save data
save hdi_results.mat *
save sub_nation_HDI_v5.mat M_hdi_*

%% plot 
load hdi_results.mat

R_00833 = georasterref('RasterSize', [2160 4320], ...
      'RasterInterpretation', 'cells', 'ColumnsStartFrom', 'north', ...
      'LatitudeLimits', [-90 90], 'LongitudeLimits', [-180 180]);

Title_hdi = {'HDI 1990', 'HDI 1995', 'HDI 2000','HDI 2005','HDI 2010', 'HDI 2015'};

temp_colormap = flipud(cbrewer('div', 'Spectral',14));
%temp_colormap(1,:) = [211/255,211/255,211/255];

figure_hdi_map = figure('pos',[10 10 1500 3000]);
for yr = 1:6
    
        subtightplot(3,2,yr,[0.1 0.1])
        temp_plot = M_hdi_final(:,:,1+5*(yr-1));
        
        axesm ('robinson', 'Frame', 'off', 'Grid', 'off','MapLatLimit',[-90 90]);
        set(gca,'CLim', [0.3, 1],'xcolor','w','ycolor','w','xtick',[],'ytick',[], 'dataAspectRatio',[1 1 1])
        geoshow(temp_plot, R_00833, 'DisplayType', 'surface');  
        %geoshow(countries,'DisplayType', 'polygon','FaceColor', 'none','LineWidth', 0.2); 
        colormap(temp_colormap)
        colorbar;
        
        
        clear temp_plot*

        title(Title_hdi(yr));    
end


saveas(figure_hdi_map,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_fig4_hdi_v4.eps','epsc');


saveas(figure_hdi_map,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_fig4_hdi_v3.tif','tif');

%% pedigree of the results

%load hdi_results.mat  % in case you do not want to run all again...

% national

[~,~, raw_country] = xlsread('/Volumes/Kummu_GIS/matlab/global_RBV/socio_indicators_hdi_1990_2015.xlsx','HDI_to_matlab'); %we only want the raw data

temp_national_hdi = raw_country(2:end,3:end); %get rid of text rows and columns
national_hdi_accuracy = cell2mat(temp_national_hdi); %convert numbers stored as text to numeric data
clearvars temp_national_hdi


% interpolated (gets value 5)
temp = national_hdi_extrapol_start;
temp(isnan(temp)) = -1;
national_hdi_accuracy(temp == -1) = 5;

% for some reason few numbers to NaN, transfer those to 0.5
national_hdi_accuracy(isnan(national_hdi_accuracy)) = 0.5;

% extrapolated (6)
national_hdi_accuracy(national_hdi_extrapol_start == -1) = 6;

% identify countries with no data (7)
temp2 = national_hdi;

temp2_part = temp2(:,3:end);
[row,col] = find(all(isnan(temp2_part),2));
national_hdi_accuracy(row,3:end) = 7;

% actual observed data (4)
national_hdi_accuracy(and(national_hdi_accuracy > 0.001,national_hdi_accuracy <1.001)) = 4;


%% sub-national pedigree to map

M_hdi_accuracy = zeros(size(adm0_5min,1),size(adm0_5min,2),size(national_hdi_filled_final,2)-2,'int8');

% help
sub_national_M_hdi_accuracy = zeros(size(M_subnat_id),'single');

% sub-national
% 1 = observed
% 2 = interpolated

% any data to 1
sub_national_M_hdi_accuracy(~sea) = 0;
% sub-national data to 2
sub_national_M_hdi_accuracy(mask_regions) = 2;
%imagesc(sub_national_M_hdi_accuracy);

for yr = 3:size(national_hdi_accuracy,2)
        
    temp_map3 = zeros(size(sub_national_M_hdi_accuracy),'int8');
    map_cntry_mask = single(adm0_5min);
    map_cntry_mask(sub_national_M_hdi_accuracy == 2) = 0; % areas with regional data to 0
        
    for cntry = 1:size(national_hdi,1)
        cntry_id = national_hdi(cntry,1);
        cntry_logical = map_cntry_mask == cntry_id;
        
        temp_map = zeros(size(map_cntry_mask),'int8');
        temp_map(cntry_logical) = int8(national_hdi_accuracy(cntry,yr));
        
        temp_map3 = temp_map3 + temp_map;
    end

    
    M_hdi_accuracy(:,:,yr-2) = temp_map3 + int8(sub_national_M_hdi_accuracy);
    clearvars temp*
end

% observed sub-national to 1
temp = M_hdi_accuracy(:,:,21);
temp(sub_national_M_hdi_accuracy == 2) = 1;
M_hdi_accuracy(:,:,21) = temp;

% sea to NaN
M_hdi_accuracy = single(M_hdi_accuracy);
M_hdi_accuracy(repmat(sea,1,1,size(M_hdi_accuracy,3))) = NaN;

temp = adm0_5min;

% antarctica to NaN
antarctica = adm0_5min == 30;
M_hdi_accuracy(repmat(antarctica,1,1,size(M_hdi_accuracy,3))) = NaN;


%% save
save M_hdi_accuracy.mat M_hdi_accuracy
%% plot accuracy
load M_hdi_accuracy.mat


R_00833 = georasterref('RasterSize', [2160 4320], ...
      'RasterInterpretation', 'cells', 'ColumnsStartFrom', 'north', ...
      'LatitudeLimits', [-90 90], 'LongitudeLimits', [-180 180]);


Title_accuracy = {'Accuracy 1990', 'Accuracy 1995', 'Accuracy 2000','Accuracy 2005','Accuracy 2010', 'Accuracy 2015'};
clear temp_colormap
temp_colormap(2:9,:) = flipud(cbrewer('div', 'RdYlBu',8));
temp_colormap(1,:) = [211/255,211/255,211/255];

figure_accuracy_map = figure('pos',[10 10 1500 3000]);

for yr = 1:6
    
        subtightplot(3,2,yr,[0.1 0.1])
        temp_plot = M_hdi_accuracy(:,:,1+5*(yr-1));
              
        axesm ('robinson', 'Frame', 'off', 'Grid', 'off','MapLatLimit',[-90 90]);
        set(gca,'CLim', [-0.5, 7.5],'xcolor','w','ycolor','w','xtick',[],'ytick',[], 'dataAspectRatio',[1 1 1])
        geoshow(temp_plot, R_00833, 'DisplayType', 'surface');  
        
        colormap(temp_colormap)
        colorbar;
        
        clear temp_plot*
        
        title(Title_accuracy(yr));
    
end


saveas(figure_accuracy_map,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_fig5_hdi_accuracy_v5.tif','tif');


saveas(figure_accuracy_map,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_fig5_hdi_accuracy_v2.eps','epsc');

%% plot distance to closest value

load hdi_distance_to_closest_value.mat
% sea to NaN
sea = land == 0;
M_extrap_dist = single(M_extrap_dist);
M_extrap_dist(repmat(sea,1,1,size(M_extrap_dist,3))) = NaN;


Title_Distance = {'Distance 1990', 'Distance 1995', 'Distance 2000','Distance 2005','Distance 2010', 'Distance 2015'};

temp_colormap(2:21,:) = flipud(cbrewer('div', 'RdYlBu',20));
temp_colormap(1,:) = [211/255,211/255,211/255];

figure_Distance_map = figure;

for yr = 1:6
    
        subtightplot(3,2,yr,[0.1 0.1])
        temp_plot = M_extrap_dist(:,:,1+5*(yr-1));
              
        b = imagesc(temp_plot);
        set(b,'AlphaData',~isnan(temp_plot))
        
        clear temp_plot*
        colormap(temp_colormap)
        set(gca, 'CLim', [-0.5, 20],'xtick',[],'ytick',[],'dataAspectRatio',[1 1 1]);
        colorbar;
        title(Title_Distance(yr));
    
end


saveas(figure_Distance_map,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_fig_hdi_Distance.eps','epsc');



%% HDI by latitudes (additional analysis)

temp_pop_weighted_hdi = M_hdi_final .* pop_2010;
temp_lat_pop = nansum(pop_2010,2);
temp_lat_pop_weighted_hdi = nansum(temp_pop_weighted_hdi,2);

% sum over one degree

temp_degree = [1:2160]';
temp_degree = floor(temp_degree / 12)+1;

temp_hid_lat_degree(:,1) = accumarray(temp_degree, temp_degree, [], @nanmean);
temp_hid_lat_degree(:,2) = accumarray(temp_degree, temp_lat_pop, [], @nansum);
temp_hid_lat_degree(:,3) = accumarray(temp_degree, temp_lat_pop_weighted_hdi, [], @nansum);

hdi_by_lat = 91-temp_hid_lat_degree(:,1);
hdi_by_lat(:,2) = temp_hid_lat_degree(:,3) ./ temp_hid_lat_degree(:,2);

