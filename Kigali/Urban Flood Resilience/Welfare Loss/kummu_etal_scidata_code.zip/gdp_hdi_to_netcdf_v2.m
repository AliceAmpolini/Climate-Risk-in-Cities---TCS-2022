%% HDI and GDP to NetCDF

clc
clear
close all
    
cd /Volumes/Kummu_GIS/matlab/global_RBV/
addpath(genpath('/Volumes/Kummu_GIS/matlab/global_RBV/'));

%% load data
load admin_areas.mat
load subnational_gdp_accuracy.mat
load subnational_gdp.mat
load gdp_total_30arcsec.mat

load('hdi_results.mat','M_hdi_final');
load M_hdi_accuracy.mat


%% calculate how many % of population covered with sub-national data

sub_national_GDP = map_subnat_accuracy(:,:,20) < 4;
sub_national_HDI = M_hdi_accuracy(:,:,20) < 4;

load '/Volumes/Kummu_GIS/datasets/hyde_3_2/pop_hyde_1981_2015.mat'

total_pop_2015 = nansum(nansum(pop_hyde_1981_2015(:,:,35)));
total_gdp_2015 = nansum(nansum(map_reg_gdp_total(:,:,26)));

pop_GDP = nansum(nansum(sub_national_GDP .* pop_hyde_1981_2015(:,:,35)));
total_GDP = nansum(nansum(sub_national_GDP .* map_reg_gdp_total(:,:,26)));
pop_HDI = nansum(nansum(sub_national_HDI .* pop_hyde_1981_2015(:,:,35)));

pop_GDP_perc = pop_GDP ./ total_pop_2015;
pop_total_GDP_perc = total_GDP ./ total_gdp_2015;
pop_HDI_perc = pop_HDI ./ total_pop_2015;

imagesc(sub_national_GDP);

clearvars sub_* pop*


%% admin areas to netcdf


temp_data = admin_areas_gdp;
temp_data(:,:,2) = admin_areas_hdi;


% NaN to -9
temp_data(isnan(temp_data)) = -9;

% possible zero to -9
temp_data(temp_data == 0) = -9;


nx=single(size(temp_data,2));
ny=single(size(temp_data,1));
nt=single(size(temp_data,3));

lon=single(linspace(-180 + (360/nx)/2,180 - (360/nx)/2,nx));
lat=single(linspace(90 - (180/ny)/2,-90 + (180/ny)/2,ny));
product=[1,2];


disp('creating netcdf file...')
filenc=['admin_areas_GDP_HDI.nc'];
variable_name = 'admin_units';

ncid = netcdf.create(filenc,'NETCDF4'); 



% create dimensions
dimid_lon = netcdf.defDim(ncid,'longitude',nx);
dimid_lat = netcdf.defDim(ncid,'latitude',ny); 
dimid_product = netcdf.defDim(ncid,'product',nt);%netcdf.getConstant('NC_UNLIMITED')); 

% create variables and attributes

%
varid_lon = netcdf.defVar(ncid,'longitude','NC_FLOAT',dimid_lon);
netcdf.putAtt(ncid,varid_lon,'standard_name','longitude')
netcdf.putAtt(ncid,varid_lon,'long_name','longitude')
netcdf.putAtt(ncid,varid_lon,'units','degrees_east')
netcdf.putAtt(ncid,varid_lon,'axis','X')

% 
varid_lat = netcdf.defVar(ncid,'latitude','NC_FLOAT',dimid_lat);
netcdf.putAtt(ncid,varid_lat,'standard_name','latitude')
netcdf.putAtt(ncid,varid_lat,'long_name','latitude')
netcdf.putAtt(ncid,varid_lat,'units','degrees_north')
netcdf.putAtt(ncid,varid_lat,'axis','Y')


%
varid_product = netcdf.defVar(ncid,'product','NC_FLOAT',dimid_product);
netcdf.putAtt(ncid,varid_product,'standard_name','Product')
netcdf.putAtt(ncid,varid_product,'long_name','Admin area product')
netcdf.putAtt(ncid,varid_product,'units','Admin id')


% 
varid_variable = netcdf.defVar(ncid,variable_name,'NC_FLOAT',[dimid_lon,dimid_lat,dimid_product]);
netcdf.putAtt(ncid,varid_variable,'long_name','Administrative areas for gridded GDP and HDI products')
netcdf.putAtt(ncid,varid_variable,'units','admin area code')
netcdf.putAtt(ncid,varid_variable,'missing_value',-9)

% compress
netcdf.defVarDeflate(ncid,varid_variable,true,true,9);

% global attributes
varid = netcdf.getConstant('GLOBAL');
netcdf.putAtt(ncid,varid,'creation_date',datestr(now));
netcdf.putAtt(ncid,varid,'resolution','5 arc-min');
netcdf.putAtt(ncid,varid,'projection','WGS84');
netcdf.putAtt(ncid,varid,'extent','lat: 90�S - 90�N; lon: 180�E - 180�W');
netcdf.putAtt(ncid,varid,'product','admin areas for GDP are in the first layer, while admin areas for HDI are in the second');
netcdf.putAtt(ncid,varid,'citation','When using the data, please refer to following publication: TBA');
netcdf.putAtt(ncid,varid,'more information','For more information, see: TBA');


% put coordinates and time
netcdf.putVar(ncid,varid_lon,lon);
netcdf.putVar(ncid,varid_lat,lat);
netcdf.putVar(ncid,varid_product,product);

% put main variable
netcdf.putVar(ncid,varid_variable,permute(temp_data,[2 1 3]));

% close netcdf
netcdf.close(ncid) 


% test

entry = ncread('admin_areas_GDP_HDI.nc', 'admin_units');

test = permute(entry(:,:,1),[2 1 3]);
imagesc(test);

ncinfo('admin_areas_GDP_HDI.nc')
%%
imagesc(M_hdi_final(:,:,26))

%% GDP per capita


temp_data = map_subnat_gdp;

% NaN to -9
temp_data(isnan(temp_data)) = -9;

% possible zero to -9
temp_data(temp_data == 0) = -9;


nx=single(size(temp_data,2));
ny=single(size(temp_data,1));
nt=single(size(temp_data,3));

lon=single(linspace(-180 + (360/nx)/2,180 - (360/nx)/2,nx));
lat=single(linspace(90 - (180/ny)/2,-90 + (180/ny)/2,ny));
time=single(1:nt)+1989;


disp('creating netcdf file...')
filenc=['GDP_per_capita_PPP_1990_2015.nc'];
variable_name = 'GDP_per_capita_PPP';

ncid = netcdf.create(filenc,'NETCDF4'); 


% create dimensions
dimid_lon = netcdf.defDim(ncid,'longitude',nx);
dimid_lat = netcdf.defDim(ncid,'latitude',ny); 
dimid_time = netcdf.defDim(ncid,'time',nt);%netcdf.getConstant('NC_UNLIMITED')); 

% create variables and attributes

%
varid_lon = netcdf.defVar(ncid,'longitude','NC_FLOAT',dimid_lon);
netcdf.putAtt(ncid,varid_lon,'standard_name','longitude')
netcdf.putAtt(ncid,varid_lon,'long_name','longitude')
netcdf.putAtt(ncid,varid_lon,'units','degrees_east')
netcdf.putAtt(ncid,varid_lon,'axis','X')

% 
varid_lat = netcdf.defVar(ncid,'latitude','NC_FLOAT',dimid_lat);
netcdf.putAtt(ncid,varid_lat,'standard_name','latitude')
netcdf.putAtt(ncid,varid_lat,'long_name','latitude')
netcdf.putAtt(ncid,varid_lat,'units','degrees_north')
netcdf.putAtt(ncid,varid_lat,'axis','Y')


%
varid_product = netcdf.defVar(ncid,'time','NC_FLOAT',dimid_time);
netcdf.putAtt(ncid,varid_product,'standard_name','Time')
netcdf.putAtt(ncid,varid_product,'long_name','Time')
netcdf.putAtt(ncid,varid_product,'units','year')
netcdf.putAtt(ncid,varid_product,'calendar','standard')

% 
varid_variable = netcdf.defVar(ncid,variable_name,'NC_FLOAT',[dimid_lon,dimid_lat,dimid_time]);
netcdf.putAtt(ncid,varid_variable,'long_name','Gross Domestic Production (GDP) per capita (PPP)')
netcdf.putAtt(ncid,varid_variable,'units','constant 2011 international US dollar')
netcdf.putAtt(ncid,varid_variable,'missing_value',-9)

% compress
netcdf.defVarDeflate(ncid,varid_variable,true,true,9);

% global attributes
varid = netcdf.getConstant('GLOBAL');
netcdf.putAtt(ncid,varid,'creation_date',datestr(now));
netcdf.putAtt(ncid,varid,'resolution','5 arc-min');
netcdf.putAtt(ncid,varid,'projection','WGS84');
netcdf.putAtt(ncid,varid,'extent','lat: 90�S - 90�N; lon: 180�E - 180�W');
netcdf.putAtt(ncid,varid,'product','Gross Domestic Production (GDP) per capita (PPP) for years 1990-2015');
netcdf.putAtt(ncid,varid,'citation','When using the data, please refer to following publication: TBA');
netcdf.putAtt(ncid,varid,'more information','For more information, see: TBA');


% put coordinates and time
netcdf.putVar(ncid,varid_lon,lon);
netcdf.putVar(ncid,varid_lat,lat);
netcdf.putVar(ncid,varid_product,time);

% put main variable
netcdf.putVar(ncid,varid_variable,permute(temp_data,[2 1 3]));

% close netcdf
netcdf.close(ncid) 

% test

entry = ncread('GDP_per_capita_PPP_1990_2015.nc', 'GDP_per_capita_PPP');
test = permute(entry(:,:,1),[2 1 3]);
imagesc(test);

ncinfo('GDP_per_capita_PPP_1990_2015.nc')

clearvars nt nx ny var* time temp* ncid lat lon filenc dimid*


%% total GDP - 5 arcmin

temp_data = map_subnat_gdp_total;
%temp_data = map_reg_gdp_total;


% NaN to -9
temp_data(isnan(temp_data)) = -9;

% possible zero to -9
%temp_data(temp_data == 0) = -9;


nx=single(size(temp_data,2));
ny=single(size(temp_data,1));
nt=single(size(temp_data,3));

lon=single(linspace(-180 + (360/nx)/2,180 - (360/nx)/2,nx));
lat=single(linspace(90 - (180/ny)/2,-90 + (180/ny)/2,ny));
time=single(1:nt)+1989;


disp('creating netcdf file...')
filenc=['GDP_PPP_1990_2015_5arcmin.nc'];
variable_name = 'GDP_PPP';

ncid = netcdf.create(filenc,'NETCDF4'); 


% create dimensions
dimid_lon = netcdf.defDim(ncid,'longitude',nx);
dimid_lat = netcdf.defDim(ncid,'latitude',ny); 
dimid_time = netcdf.defDim(ncid,'time',nt);%netcdf.getConstant('NC_UNLIMITED')); 

% create variables and attributes

%
varid_lon = netcdf.defVar(ncid,'longitude','NC_FLOAT',dimid_lon);
netcdf.putAtt(ncid,varid_lon,'standard_name','longitude')
netcdf.putAtt(ncid,varid_lon,'long_name','longitude')
netcdf.putAtt(ncid,varid_lon,'units','degrees_east')
netcdf.putAtt(ncid,varid_lon,'axis','X')

% 
varid_lat = netcdf.defVar(ncid,'latitude','NC_FLOAT',dimid_lat);
netcdf.putAtt(ncid,varid_lat,'standard_name','latitude')
netcdf.putAtt(ncid,varid_lat,'long_name','latitude')
netcdf.putAtt(ncid,varid_lat,'units','degrees_north')
netcdf.putAtt(ncid,varid_lat,'axis','Y')


%
varid_product = netcdf.defVar(ncid,'time','NC_FLOAT',dimid_time);
netcdf.putAtt(ncid,varid_product,'standard_name','Time')
netcdf.putAtt(ncid,varid_product,'long_name','Time')
netcdf.putAtt(ncid,varid_product,'units','year')
netcdf.putAtt(ncid,varid_product,'calendar','standard')

% 
varid_variable = netcdf.defVar(ncid,variable_name,'NC_FLOAT',[dimid_lon,dimid_lat,dimid_time]);
netcdf.putAtt(ncid,varid_variable,'long_name','Gross Domestic Production (GDP) (PPP)')
netcdf.putAtt(ncid,varid_variable,'units','constant 2011 international US dollar')
netcdf.putAtt(ncid,varid_variable,'missing_value',-9)

% compress
netcdf.defVarDeflate(ncid,varid_variable,true,true,9);

% global attributes
varid = netcdf.getConstant('GLOBAL');
netcdf.putAtt(ncid,varid,'creation_date',datestr(now));
netcdf.putAtt(ncid,varid,'resolution','5 arc-min');
netcdf.putAtt(ncid,varid,'projection','WGS84');
netcdf.putAtt(ncid,varid,'extent','lat: 90�S - 90�N; lon: 180�E - 180�W');
netcdf.putAtt(ncid,varid,'product','Total Gross Domestic Production (GDP) (PPP) for years 1990-2015');
netcdf.putAtt(ncid,varid,'citation','When using the data, please refer to following publication: TBA');
netcdf.putAtt(ncid,varid,'more information','For more information, see: TBA');


% put coordinates and time
netcdf.putVar(ncid,varid_lon,lon);
netcdf.putVar(ncid,varid_lat,lat);
netcdf.putVar(ncid,varid_product,time);

% put main variable
netcdf.putVar(ncid,varid_variable,permute(temp_data,[2 1 3]));

% close netcdf
netcdf.close(ncid) 

% test

entry = ncread('GDP_PPP_1990_2015_5arcmin.nc', 'GDP_PPP');
test = permute(entry(:,:,1),[2 1 3]);
imagesc(test);

ncinfo('GDP_PPP_1990_2015_5arcmin.nc')

clearvars nt nx ny var* time temp* ncid lat lon filenc dimid*




%% total GDP - 30 arcsec

temp_data = gdp_total_30arcsec;

% NaN to -9
temp_data(isnan(temp_data)) = -9;

% possible zero to -9
temp_data(temp_data == 0) = -9;


nx=single(size(temp_data,2));
ny=single(size(temp_data,1));
nt=single(size(temp_data,3));

lon=single(linspace(-180 + (360/nx)/2,180 - (360/nx)/2,nx));
lat=single(linspace(90 - (180/ny)/2,-90 + (180/ny)/2,ny));
time=single([1990,2000,2015]);


disp('creating netcdf file...')
filenc=['GDP_PPP_30arcsec.nc'];
variable_name = 'GDP_PPP';

ncid = netcdf.create(filenc,'NETCDF4'); 


% create dimensions
dimid_lon = netcdf.defDim(ncid,'longitude',nx);
dimid_lat = netcdf.defDim(ncid,'latitude',ny); 
dimid_time = netcdf.defDim(ncid,'time',nt);%netcdf.getConstant('NC_UNLIMITED')); 

% create variables and attributes

%
varid_lon = netcdf.defVar(ncid,'longitude','NC_FLOAT',dimid_lon);
netcdf.putAtt(ncid,varid_lon,'standard_name','longitude')
netcdf.putAtt(ncid,varid_lon,'long_name','longitude')
netcdf.putAtt(ncid,varid_lon,'units','degrees_east')
netcdf.putAtt(ncid,varid_lon,'axis','X')

% 
varid_lat = netcdf.defVar(ncid,'latitude','NC_FLOAT',dimid_lat);
netcdf.putAtt(ncid,varid_lat,'standard_name','latitude')
netcdf.putAtt(ncid,varid_lat,'long_name','latitude')
netcdf.putAtt(ncid,varid_lat,'units','degrees_north')
netcdf.putAtt(ncid,varid_lat,'axis','Y')


%
varid_product = netcdf.defVar(ncid,'time','NC_FLOAT',dimid_time);
netcdf.putAtt(ncid,varid_product,'standard_name','Time')
netcdf.putAtt(ncid,varid_product,'long_name','Time')
netcdf.putAtt(ncid,varid_product,'units','year')
netcdf.putAtt(ncid,varid_product,'calendar','standard')

% 
varid_variable = netcdf.defVar(ncid,variable_name,'NC_FLOAT',[dimid_lon,dimid_lat,dimid_time]);
netcdf.putAtt(ncid,varid_variable,'long_name','Gross Domestic Production (GDP) (PPP)')
netcdf.putAtt(ncid,varid_variable,'units','constant 2011 international US dollar')
netcdf.putAtt(ncid,varid_variable,'missing_value',-9)

% compress
netcdf.defVarDeflate(ncid,varid_variable,true,true,9);

% global attributes
varid = netcdf.getConstant('GLOBAL');
netcdf.putAtt(ncid,varid,'creation_date',datestr(now));
netcdf.putAtt(ncid,varid,'resolution','30 arc-sec');
netcdf.putAtt(ncid,varid,'projection','WGS84');
netcdf.putAtt(ncid,varid,'extent','lat: 90�S - 90�N; lon: 180�E - 180�W');
netcdf.putAtt(ncid,varid,'product','Total Gross Domestic Production (GDP) (PPP) for years 1990, 2000 and 2015');
netcdf.putAtt(ncid,varid,'citation','When using the data, please refer to following publication: TBA');
netcdf.putAtt(ncid,varid,'more information','For more information, see: TBA');


% put coordinates and time
netcdf.putVar(ncid,varid_lon,lon);
netcdf.putVar(ncid,varid_lat,lat);
netcdf.putVar(ncid,varid_product,time);

% put main variable
netcdf.putVar(ncid,varid_variable,permute(temp_data,[2 1 3]));

% close netcdf
netcdf.close(ncid) 

% test

entry = ncread('GDP_PPP_1990_2015_5arcmin.nc', 'GDP_PPP');
test = permute(entry(:,:,1),[2 1 3]);
imagesc(test);

ncinfo('GDP_PPP_1990_2015_5arcmin.nc')

clearvars nt nx ny var* time temp* ncid lat lon filenc dimid*


%%


%% GDP pedigree

temp_data = map_subnat_accuracy;


% NaN to -9
temp_data(isnan(temp_data)) = -9;

% possible zero to -9
temp_data(temp_data == 0) = -9;


nx=single(size(temp_data,2));
ny=single(size(temp_data,1));
nt=single(size(temp_data,3));

lon=single(linspace(-180 + (360/nx)/2,180 - (360/nx)/2,nx));
lat=single(linspace(90 - (180/ny)/2,-90 + (180/ny)/2,ny));
time=single(1:nt)+1989;


disp('creating netcdf file...')
filenc=['pedigree_GDP_per_capita_PPP_1990_2015.nc'];
variable_name = 'pedigree_GDP_per_capita_PPP';

ncid = netcdf.create(filenc,'NETCDF4'); 


% create dimensions
dimid_lon = netcdf.defDim(ncid,'longitude',nx);
dimid_lat = netcdf.defDim(ncid,'latitude',ny); 
dimid_time = netcdf.defDim(ncid,'time',nt);%netcdf.getConstant('NC_UNLIMITED')); 

% create variables and attributes

%
varid_lon = netcdf.defVar(ncid,'longitude','NC_FLOAT',dimid_lon);
netcdf.putAtt(ncid,varid_lon,'standard_name','longitude')
netcdf.putAtt(ncid,varid_lon,'long_name','longitude')
netcdf.putAtt(ncid,varid_lon,'units','degrees_east')
netcdf.putAtt(ncid,varid_lon,'axis','X')

% 
varid_lat = netcdf.defVar(ncid,'latitude','NC_FLOAT',dimid_lat);
netcdf.putAtt(ncid,varid_lat,'standard_name','latitude')
netcdf.putAtt(ncid,varid_lat,'long_name','latitude')
netcdf.putAtt(ncid,varid_lat,'units','degrees_north')
netcdf.putAtt(ncid,varid_lat,'axis','Y')


%
varid_product = netcdf.defVar(ncid,'time','NC_FLOAT',dimid_time);
netcdf.putAtt(ncid,varid_product,'standard_name','Time')
netcdf.putAtt(ncid,varid_product,'long_name','Time')
netcdf.putAtt(ncid,varid_product,'units','year')
netcdf.putAtt(ncid,varid_product,'calendar','standard')

% 
varid_variable = netcdf.defVar(ncid,variable_name,'NC_FLOAT',[dimid_lon,dimid_lat,dimid_time]);
netcdf.putAtt(ncid,varid_variable,'long_name','Pedigree of Gross Domestic Production (GDP) per capita (PPP)')
netcdf.putAtt(ncid,varid_variable,'units','Pedigree index numbers, coded as follows: 1-regional reported; 2-regional interpolated; 3-regional extrapolated; 5-national reported; 6-national interpolated; 7-national extrapolatedr')
netcdf.putAtt(ncid,varid_variable,'missing_value',-9)

% compress
netcdf.defVarDeflate(ncid,varid_variable,true,true,9);

% global attributes
varid = netcdf.getConstant('GLOBAL');
netcdf.putAtt(ncid,varid,'creation_date',datestr(now));
netcdf.putAtt(ncid,varid,'resolution','5 arc-min');
netcdf.putAtt(ncid,varid,'projection','WGS84');
netcdf.putAtt(ncid,varid,'extent','lat: 90�S - 90�N; lon: 180�E - 180�W');
netcdf.putAtt(ncid,varid,'product','Pedigree data of Gross Domestic Production (GDP) per capita (PPP) for year 1990-2015');
netcdf.putAtt(ncid,varid,'citation','When using the data, please refer to following publication: TBA');
netcdf.putAtt(ncid,varid,'more information','For more information, see: TBA');


% put coordinates and time
netcdf.putVar(ncid,varid_lon,lon);
netcdf.putVar(ncid,varid_lat,lat);
netcdf.putVar(ncid,varid_product,time);

% put main variable
netcdf.putVar(ncid,varid_variable,permute(temp_data,[2 1 3]));

% close netcdf
netcdf.close(ncid) 

% test

entry = ncread('pedigree_GDP_per_capita_PPP_1990_2015.nc', 'pedigree_GDP_per_capita_PPP');
test = permute(entry(:,:,1),[2 1 3]);
imagesc(test);

ncinfo('pedigree_GDP_per_capita_PPP_1990_2015.nc')

clearvars nt nx ny var* time temp* ncid lat lon filenc dimid*





%%


%% HDI

temp_data = M_hdi_final;



% NaN to -9
temp_data(isnan(temp_data)) = -9;

% possible zero to -9
temp_data(temp_data == 0) = -9;


nx=single(size(temp_data,2));
ny=single(size(temp_data,1));
nt=single(size(temp_data,3));

lon=single(linspace(-180 + (360/nx)/2,180 - (360/nx)/2,nx));
lat=single(linspace(90 - (180/ny)/2,-90 + (180/ny)/2,ny));
time=single(1:nt)+1989;


disp('creating netcdf file...')
filenc=['HDI_1990_2015.nc'];
variable_name = 'HDI';

ncid = netcdf.create(filenc,'NETCDF4'); 


% create dimensions
dimid_lon = netcdf.defDim(ncid,'longitude',nx);
dimid_lat = netcdf.defDim(ncid,'latitude',ny); 
dimid_time = netcdf.defDim(ncid,'time',nt);%netcdf.getConstant('NC_UNLIMITED')); 

% create variables and attributes

%
varid_lon = netcdf.defVar(ncid,'longitude','NC_FLOAT',dimid_lon);
netcdf.putAtt(ncid,varid_lon,'standard_name','longitude')
netcdf.putAtt(ncid,varid_lon,'long_name','longitude')
netcdf.putAtt(ncid,varid_lon,'units','degrees_east')
netcdf.putAtt(ncid,varid_lon,'axis','X')

% 
varid_lat = netcdf.defVar(ncid,'latitude','NC_FLOAT',dimid_lat);
netcdf.putAtt(ncid,varid_lat,'standard_name','latitude')
netcdf.putAtt(ncid,varid_lat,'long_name','latitude')
netcdf.putAtt(ncid,varid_lat,'units','degrees_north')
netcdf.putAtt(ncid,varid_lat,'axis','Y')


%
varid_product = netcdf.defVar(ncid,'time','NC_FLOAT',dimid_time);
netcdf.putAtt(ncid,varid_product,'standard_name','Time')
netcdf.putAtt(ncid,varid_product,'long_name','Time')
netcdf.putAtt(ncid,varid_product,'units','year')
netcdf.putAtt(ncid,varid_product,'calendar','standard')

% 
varid_variable = netcdf.defVar(ncid,variable_name,'NC_FLOAT',[dimid_lon,dimid_lat,dimid_time]);
netcdf.putAtt(ncid,varid_variable,'long_name','Human Development Index (HDI)')
netcdf.putAtt(ncid,varid_variable,'units','dimensionless indicator')
netcdf.putAtt(ncid,varid_variable,'missing_value',-9)

% compress
netcdf.defVarDeflate(ncid,varid_variable,true,true,9);

% global attributes
varid = netcdf.getConstant('GLOBAL');
netcdf.putAtt(ncid,varid,'creation_date',datestr(now));
netcdf.putAtt(ncid,varid,'resolution','5 arc-min');
netcdf.putAtt(ncid,varid,'projection','WGS84');
netcdf.putAtt(ncid,varid,'extent','lat: 90�S - 90�N; lon: 180�E - 180�W');
netcdf.putAtt(ncid,varid,'product','Human Development Index (HDI) for years 1990-2015');
netcdf.putAtt(ncid,varid,'citation','When using the data, please refer to following publication: TBA');
netcdf.putAtt(ncid,varid,'more information','For more information, see: TBA');


% put coordinates and time
netcdf.putVar(ncid,varid_lon,lon);
netcdf.putVar(ncid,varid_lat,lat);
netcdf.putVar(ncid,varid_product,time);

% put main variable
netcdf.putVar(ncid,varid_variable,permute(temp_data,[2 1 3]));

% close netcdf
netcdf.close(ncid) 

% test

entry = ncread('HDI_1990_2015.nc', 'HDI');
test = permute(entry(:,:,1),[2 1 3]);
imagesc(test);

ncinfo('HDI_1990_2015.nc')

clearvars nt nx ny var* time temp* ncid lat lon filenc dimid*



%%


%% HDI accuracy


temp_data = M_hdi_accuracy;


% NaN to -9
temp_data(isnan(temp_data)) = -9;

% possible zero to -9
temp_data(temp_data == 0) = -9;


nx=single(size(temp_data,2));
ny=single(size(temp_data,1));
nt=single(size(temp_data,3));

lon=single(linspace(-180 + (360/nx)/2,180 - (360/nx)/2,nx));
lat=single(linspace(90 - (180/ny)/2,-90 + (180/ny)/2,ny));
time=single(1:nt)+1989;


disp('creating netcdf file...')
filenc=['pedigree_HDI_1990_2015.nc'];
variable_name = 'pedigree_HDI';

ncid = netcdf.create(filenc,'NETCDF4'); 


% create dimensions
dimid_lon = netcdf.defDim(ncid,'longitude',nx);
dimid_lat = netcdf.defDim(ncid,'latitude',ny); 
dimid_time = netcdf.defDim(ncid,'time',nt);%netcdf.getConstant('NC_UNLIMITED')); 

% create variables and attributes

%
varid_lon = netcdf.defVar(ncid,'longitude','NC_FLOAT',dimid_lon);
netcdf.putAtt(ncid,varid_lon,'standard_name','longitude')
netcdf.putAtt(ncid,varid_lon,'long_name','longitude')
netcdf.putAtt(ncid,varid_lon,'units','degrees_east')
netcdf.putAtt(ncid,varid_lon,'axis','X')

% 
varid_lat = netcdf.defVar(ncid,'latitude','NC_FLOAT',dimid_lat);
netcdf.putAtt(ncid,varid_lat,'standard_name','latitude')
netcdf.putAtt(ncid,varid_lat,'long_name','latitude')
netcdf.putAtt(ncid,varid_lat,'units','degrees_north')
netcdf.putAtt(ncid,varid_lat,'axis','Y')


%
varid_product = netcdf.defVar(ncid,'time','NC_FLOAT',dimid_time);
netcdf.putAtt(ncid,varid_product,'standard_name','Time')
netcdf.putAtt(ncid,varid_product,'long_name','Time')
netcdf.putAtt(ncid,varid_product,'units','year')
netcdf.putAtt(ncid,varid_product,'calendar','standard')

% 
varid_variable = netcdf.defVar(ncid,variable_name,'NC_FLOAT',[dimid_lon,dimid_lat,dimid_time]);
netcdf.putAtt(ncid,varid_variable,'long_name','Pedigree of Human Development Index (HDI)')
netcdf.putAtt(ncid,varid_variable,'units','Pedigree index numbers, coded as follows: 1-regional reported; 2-regional scaled; 4-national reported; 5-national interpolated; 6-national extrapolated; 7-no data, regional average used')
netcdf.putAtt(ncid,varid_variable,'missing_value',-9)

% compress
netcdf.defVarDeflate(ncid,varid_variable,true,true,9);

% global attributes
varid = netcdf.getConstant('GLOBAL');
netcdf.putAtt(ncid,varid,'creation_date',datestr(now));
netcdf.putAtt(ncid,varid,'resolution','5 arc-min');
netcdf.putAtt(ncid,varid,'projection','WGS84');
netcdf.putAtt(ncid,varid,'extent','lat: 90�S - 90�N; lon: 180�E - 180�W');
netcdf.putAtt(ncid,varid,'product','Pedigree data of Human Development Index (HDI) for years 1990-2015');
netcdf.putAtt(ncid,varid,'citation','When using the data, please refer to following publication: TBA');
netcdf.putAtt(ncid,varid,'more information','For more information, see: TBA');


% put coordinates and time
netcdf.putVar(ncid,varid_lon,lon);
netcdf.putVar(ncid,varid_lat,lat);
netcdf.putVar(ncid,varid_product,time);

% put main variable
netcdf.putVar(ncid,varid_variable,permute(temp_data,[2 1 3]));

% close netcdf
netcdf.close(ncid) 

% test

entry = ncread('pedigree_HDI_1990_2015.nc', 'pedigree_HDI');
test = permute(entry(:,:,1),[2 1 3]);
imagesc(test);

ncinfo('pedigree_HDI_1990_2015.nc')

clearvars nt nx ny var* time temp* ncid lat lon filenc dimid*


%%
%% to geotiff

% write to geotiff
R_5arcmin = georasterref('RasterSize', [2160 4320], ...
    'RasterInterpretation', 'cells', 'ColumnsStartFrom', 'north', ...
    'LatitudeLimits', [-90 90], 'LongitudeLimits', [-180 180]);

R_30arcsec = georasterref('RasterSize', [21600 43200], ...
    'RasterInterpretation', 'cells', 'ColumnsStartFrom', 'north', ...
    'LatitudeLimits', [-90 90], 'LongitudeLimits', [-180 180]);

area_5arcmin = areacell(0.083333333);
area_30arcsec = areacell(0.0083333333);

%geotiffwrite('/Volumes/Kummu_GIS/matlab/global_RBV/output/gdp_per_cap_05arcmin_int.tif',int32(map_reg_gdp(:,:,26)),R_5arcmin);
temp = (map_reg_gdp_total(:,:,26)./1000000) ./ area_5arcmin;
geotiffwrite('/Volumes/Kummu_GIS/matlab/global_RBV/output/gdp_total_05arcmin.tif',temp,R_5arcmin);
temp = (gdp_total_30arcsec(:,:,3)./1000000) ./ area_30arcsec;
geotiffwrite('/Volumes/Kummu_GIS/matlab/global_RBV/output/gdp_total_30arcsec.tif',temp,R_30arcsec);


%imagesc(map_reg_gdp(:,:,26))

%% to arcgis raster (please note, the example ascii files are not available)
load raster_to_ascii.mat
area_5arcmin = areacell(0.083333333);
area_30arcsec = areacell(0.0083333333);
% 
% [temp_raster,temp_X,temp_Y] = rasterread('/Volumes/Kummu_GIS/matlab/global_RBV/output/example.asc');
% [temp_raster30,temp_X30,temp_Y30] = rasterread('/Volumes/Kummu_GIS/matlab/global_RBV/output/example_30arccsec.asc');
% %
rasterwrite('/Volumes/Kummu_GIS/matlab/global_RBV/output/gdp_perc_cap_1k.asc',temp_X,temp_Y,map_reg_gdp(:,:,26)/1000);

temp = (map_reg_gdp_total(:,:,26)/1000000) ./ area_5arcmin;
rasterwrite('/Volumes/Kummu_GIS/matlab/global_RBV/output/gdp_total_5arcmin_1m.asc',temp_X,temp_Y,temp);

national_gdp = geotiffread('/Volumes/Kummu_GIS/matlab/global_RBV/output/gdp_per_cap_national.tif');
rasterwrite('/Volumes/Kummu_GIS/matlab/global_RBV/output/gdp_perc_cap_national_1k.asc',temp_X,temp_Y,national_gdp/1000);

temp = (gdp_total_30arcsec(:,:,3)./1000000) ./ area_30arcsec;
rasterwrite('/Volumes/Kummu_GIS/matlab/global_RBV/output/gdp_total_30arcsec_1m.asc',temp_X,temp_Y,temp);
clearvars *30*

save raster_to_ascii.mat temp_X* temp_Y*

imagesc(temp_X30);







