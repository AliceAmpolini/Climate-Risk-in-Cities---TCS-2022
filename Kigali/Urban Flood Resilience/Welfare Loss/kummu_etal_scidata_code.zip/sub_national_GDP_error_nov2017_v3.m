%% error estimates for subnational GDP data
% please note: you need to run first the sub_national_GDP_jul2017_v2.m, as
% some output from there is needed here

clc
clear
close all
    
cd /Volumes/Kummu_GIS/matlab/global_RBV/
addpath(genpath('/Volumes/Kummu_GIS/matlab/global_RBV/'));

%% error in national data

%% sub-national data

% sub-national database
% based on Regions data from Gennaioli, Nicola, Rafael LaPorta, Florencio Lopez-de-Silanes, and Andrei Shleifer. 2013. ?Human Capital and Regional Development.? Quarterly Journal of Economics 128 (1): 105-164
% http://scholar.harvard.edu/shleifer/publications?page=1		
% 1950-2010
subnational_gdp = xlsread('/Users/mkummu/Documents/work/publications/varis_al_global_RBV/gdp_region_matrix.xlsx','gdp_matrix','H4:BR1531');
subnational_gdp = [subnational_gdp(2:end,1:2), subnational_gdp(2:end,43:end)];

% select subnational units with full data
for i = 1:size(subnational_gdp,1)
    temp = subnational_gdp(i,3:end);
    temp_gdp_count(i,1) = sum(temp(:) > 0);
end

[row,col] = find(temp_gdp_count == nanmax(temp_gdp_count));

subnat_gdp_fulldata = subnational_gdp(row,:);

%% subnat error in interpolation v2

% how many repetitions (i.e. the start of the interpolation)
m_n = 21;
% over how many values is the largest interpolation
h_n = 19;

subnat_gdp_fulldata_error_v2 = zeros(size(subnat_gdp_fulldata,1),size(subnat_gdp_fulldata,2),m_n,h_n);
subnat_gdp_fulldata_error_v2(:,1,:,:) = repmat(subnat_gdp_fulldata(:,1),1,1,m_n,h_n);

for h = 1:h_n 
    
    for m = 1:m_n-h
        temp_data = subnat_gdp_fulldata; % read data
      
        temp_data(:,3+m:3+m+h-1) = NaN; % mark NaN the values over which we want to interpolate
        
        for i = 1:size(subnat_gdp_fulldata,1)
            temp = temp_data(i,3:end); 
            
            temp_interp = inpaint_nans(temp,3); % use inpaint_nans for interpolation
            
            subnat_gdp_fulldata_error_v2(i,3:end,m,h) = temp_interp; % collect results
            
        end
    end
end

clearvars temp* lo i ans h m 

%% subnat estimate error
size(subnat_gdp_fulldata_error_v2);
temp_error_int = zeros(size(subnat_gdp_fulldata_error_v2));

% estimate error by comparing the interpolated results to the actually
% reported data points
for h = 1:h_n
    for m = 1:m_n-h
        temp_error_int(:,2+m:2+m+h-1,m,h) = abs(subnat_gdp_fulldata(:,2+m:2+m+h-1) - subnat_gdp_fulldata_error_v2(:,2+m:2+m+h-1,m,h));
    end
end
size(temp_error_int);

% normalise error
temp_error_norm = temp_error_int ./ repmat(subnat_gdp_fulldata,1,1,m_n,h_n);
temp_error_norm(temp_error_norm == 0) = NaN;
temp_error_norm(temp_error_norm == 1) = NaN;

% select the values that are within same distance from known value to
% express the error with the function of distance

for h = 1:h_n
    for m = 1:m_n-h
        
        temp_size = size(2+m:2+m+h-1,2);
        temp = temp_error_norm(:,2+m:2+m+h-1,m,h);
        
        for i = 1:floor(temp_size/2)+1
            if i < floor(temp_size/2)+1
                temp_collect(:,m,h,i) = temp(:,i);
            else
                temp_collect(:,m,h,temp_size-i+1) = temp(:,i);
            end
        end
        
    end
end

for i = 1:size(temp_collect,4)
    temp = temp_collect(:,:,:,i);
    subnat_gdp_int_error_collect(:,i) = temp(:);
    
end

% zero values sto NaN
subnat_gdp_int_error_collect(subnat_gdp_int_error_collect == 0) = NaN;

% mean error
global_subnat_gdp_int_error_norm_mean = (squeeze( nanmean(subnat_gdp_int_error_collect,1)));

for i = 1:size(subnat_gdp_int_error_collect,2)
    temp_pd = fitdist(subnat_gdp_int_error_collect(:,i),'Normal'); %fit propability distribution
    temp_ci = paramci(temp_pd); % confidence interval using pd
    global_subnat_gdp_int_error_norm_ci(:,i) = temp_ci(:,1); % collect results
end

% plot
fig_subnat_gdp_int = figure;
confplot(1:10,global_subnat_gdp_int_error_norm_mean,global_subnat_gdp_int_error_norm_mean-global_subnat_gdp_int_error_norm_ci(1,:),global_subnat_gdp_int_error_norm_ci(2,:)-global_subnat_gdp_int_error_norm_mean); 
ylim([0,1])

saveas(fig_subnat_gdp_int,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_error_subnat_gdp_int.eps','epsc');
clearvars temp* lo i ans h m h_n m_n

%% subnat error in extrapolation
% subnational extrapolation was done with using the trend from national
% data

% national database
% based on worldbank development indicators (GDP per capita)
% 1990-2015
national_gdp = xlsread('/Users/mkummu/Documents/work/publications/varis_al_global_RBV/GDP_From_World_Development_Indicators.xlsx','Data','C2:AC220');

% define how many 'rounds' (i.e. max distance to closest value)
n = 19;

subnat_gdp_extrapol = zeros(size(subnat_gdp_fulldata));
subnat_gdp_extrapol(:,1:2) = subnat_gdp_fulldata(:,1:2);

subnat_gdp_extrapol = repmat(subnat_gdp_extrapol,1,1,n);


for n_start = 1:n
    subnat_gdp_extrapol_start = zeros(1,size(subnat_gdp_fulldata,2));
    subnat_gdp_extrapol_start(1,3:2+n_start) = -1;
    
    % the first years
    for i = 1:size(subnat_gdp_fulldata,1)
        temp_cntry_id = subnat_gdp_fulldata(i,1); % country id
        temp_subnat_row = i;
        
        [row,col] = find(fliplr(subnat_gdp_extrapol_start(1,3:end) == -1));
        
        
        if isempty(col) % in case no need to extrapolate
            
        elseif size(col,2) == 26 % in case no data at all
            
            
        else
            
            [row_cntry,col_cntry] = find(national_gdp(:,1) == temp_cntry_id);
            % flip
            temp_cntry_gdp = fliplr(national_gdp(row_cntry,2:end-5)); % find the correct national value           
            
            temp_cntry_gdp = temp_cntry_gdp(1,(col(1,1)-1:end));
         
            temp_subnat_gdp = fliplr(subnat_gdp_fulldata(i,3:end));
            
            temp_subnat_final_entry = temp_subnat_gdp(1,col(1,1)-1);
            temp_diff = temp_subnat_final_entry ./ temp_cntry_gdp(1,1); % ratio between macro-regions value and last reported national value
            
            % scale based on meta-area value
            temp_subnat_gdp_2015 = temp_diff .* temp_cntry_gdp(1,2:end);
            
            %temp_reg(1,col(1,1):end) = temp_subnat_gdp;
            % fill the matrix
            subnat_gdp_extrapol(i,3:3+size(col,2)-1,n_start) = fliplr(temp_subnat_gdp_2015);
        end
    end
end
clearvars temp* i k col* row* 


%% subnat calculate error
subnat_gdp_extrapol_error = zeros(size(subnat_gdp_extrapol));
% difference between the reported data and value calculated with regional trends
for n_start = 1:n
    subnat_gdp_extrapol_error(:,3:2+n_start,n_start) = abs(subnat_gdp_fulldata(:,3:2+n_start) - subnat_gdp_extrapol(:,3:2+n_start,n_start)); 
end

% normalise error
subnat_gdp_extrapol_error_norm = subnat_gdp_extrapol_error ./ repmat(subnat_gdp_fulldata,1,1,n);
subnat_gdp_extrapol_error_norm(subnat_gdp_extrapol_error_norm==0) = NaN;

for i = 1:size(subnat_gdp_extrapol_error_norm,3)
    temp = subnat_gdp_extrapol_error_norm(:,3:2+i,i);    
    temp_collect(:,1:i,i) = fliplr( temp);    
end


for i = 1:size(temp_collect,2)
    temp = temp_collect(:,i,:);
    subnat_gdp_extr_error_collect(:,i) = temp(:);    
end

subnat_gdp_extr_error_collect(subnat_gdp_extr_error_collect == 0) = NaN;

global_subnat_gdp_ext_error_norm_mean = (squeeze( nanmean(subnat_gdp_extr_error_collect,1)));

for i = 1:size(subnat_gdp_extr_error_collect,2)
    temp_pd = fitdist(subnat_gdp_extr_error_collect(:,i),'Normal'); %fit propability distribution
    temp_ci = paramci(temp_pd); % confidence interval using pd
    global_subnat_gdp_extr_error_norm_ci(:,i) = temp_ci(:,1); % collect results
end

% plot
fig_subnat_gdp_ext = figure;
confplot(1:size(global_subnat_gdp_ext_error_norm_mean,2),global_subnat_gdp_ext_error_norm_mean,global_subnat_gdp_ext_error_norm_mean-global_subnat_gdp_extr_error_norm_ci(1,:),global_subnat_gdp_extr_error_norm_ci(2,:)-global_subnat_gdp_ext_error_norm_mean); 
ylim([0,1])

saveas(fig_subnat_gdp_ext,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_error_subnat_gdp_ext.eps','epsc');

%% to map

load subnat_gdp_distance_to_closest_value.mat % saved in sub_national_GDP_jul2017_v2.m
load('hdi_spatial_extent.mat','land');

M_subnat_maxdist_int = nanmax(map_interp_count,[],3);
M_subnat_maxdist_ext = nanmax(map_extrap_count,[],3);
M_subnat_maxerror_int = zeros(size(M_subnat_maxdist_int),'single');
M_subnat_maxerror_ext = zeros(size(M_subnat_maxdist_ext),'single');

for i = 1:size(global_subnat_gdp_int_error_norm_mean,2)
    temp_error_int = global_subnat_gdp_int_error_norm_mean(1,i);
    
    temp_mask_int = M_subnat_maxdist_int == i;
    
    M_subnat_maxerror_int(temp_mask_int) = temp_error_int;    
end

for i = 1:size(global_subnat_gdp_int_error_norm_mean,2)
    
    temp_error_ext = global_subnat_gdp_ext_error_norm_mean(1,i);
      
    temp_mask_ext = M_subnat_maxdist_ext == i;
       
    M_subnat_maxerror_ext(temp_mask_ext) = temp_error_ext;
    
end

sea = land == 0;

M_subnat_maxerror_int(sea) = NaN;

M_subnat_maxerror_ext(sea) = NaN;


save gdp_subnat_error.mat M_subnat_max*

%% error in national data

%% read country data

% national database
% based on worldbank development indicators (GDP per capita)
% 1990-2015
national_gdp = xlsread('/Users/mkummu/Documents/work/publications/varis_al_global_RBV/GDP_From_World_Development_Indicators.xlsx','Data','C2:AC220');
national_2015USD = xlsread('/Users/mkummu/Documents/work/publications/varis_al_global_RBV/GDP_From_World_Development_Indicators.xlsx','Data','AH2:AH220');


%% load data

% above calculated subnational error
load gdp_subnat_error.mat

% calculated in sub-national_GDP_nov2017_v3.m
load macroreg_gdp.mat


%% select countries with full data

% done in sub-national_GDP_nov2017_v3.m

for i = 1:size(temp_national_gdp,1)
    temp_id = temp_national_gdp(i,1);
    [row,col] = find(national_gdp(:,1) == temp_id);
    national_gdp_fulldata(i,:) = national_gdp(row,:);
    macroreg_id_sel(i,:) = macroreg_id_cntry(row,:);
end


clearvars temp* row col

%% error in interpolation v2

% how many repetitions
m_n = 24;
% over how many values is the largest interpolation
h_n = 21;

national_gdp_fulldata_error_v2 = zeros(size(national_gdp_fulldata,1),size(national_gdp_fulldata,2),m_n,h_n);
national_gdp_fulldata_error_v2(:,1,:,:) = repmat(national_gdp_fulldata(:,1),1,1,m_n,h_n);

for h = 1:h_n
    
    
    for m = 1:m_n-h
        temp_data = national_gdp_fulldata; % read data
   
        temp_data(:,3+m:3+m+h-1) = NaN; % mark NaN the values over which we want to interpolate
        for i = 1:size(national_gdp_fulldata,1)
            temp = temp_data(i,2:end);
            
            temp_interp = inpaint_nans(temp,3); % use inpaint_nans for interpolation
            
            national_gdp_fulldata_error_v2(i,2:end,m,h) = temp_interp; % store data

        end
        
        
    end
end

clearvars temp* lo i ans h m 

%% estimate error
size(national_gdp_fulldata_error_v2);
temp_error_int = zeros(size(national_gdp_fulldata_error_v2));

% estimate error by comparing the interpolated results to the actually
% reported data points
for h = 1:h_n
    for m = 1:m_n-h
        temp_error_int(:,2+m:2+m+h-1,m,h) = abs(national_gdp_fulldata(:,2+m:2+m+h-1) - national_gdp_fulldata_error_v2(:,2+m:2+m+h-1,m,h));
    end
end
size(temp_error_int);

% normalise error
temp_error_norm = temp_error_int ./ repmat(national_gdp_fulldata,1,1,m_n,h_n);
temp_error_norm(temp_error_norm == 0) = NaN;
temp_error_norm(temp_error_norm == 1) = NaN;

% select the values that are within same distance from known value to
% express the error with the function of distance

for h = 1:h_n
    for m = 1:m_n-h
        
        temp_size = size(2+m:2+m+h-1,2);
        temp = temp_error_norm(:,2+m:2+m+h-1,m,h);
        
        for i = 1:floor(temp_size/2)+1
            if i < floor(temp_size/2)+1
                temp_collect(:,m,h,i) = temp(:,i);
            else
                temp_collect(:,m,h,temp_size-i+1) = temp(:,i);
            end
        end
        
    end
end

for i = 1:size(temp_collect,4)
    temp = temp_collect(:,:,:,i);
    gdp_int_error_collect(:,i) = temp(:);
    
end

gdp_int_error_collect(gdp_int_error_collect == 0) = NaN;


global_gdp_int_error_norm_mean = (squeeze( nanmean(gdp_int_error_collect,1)));

for i = 1:size(gdp_int_error_collect,2)
    temp_pd = fitdist(gdp_int_error_collect(:,i),'Normal'); %fit propability distribution
    temp_ci = paramci(temp_pd); % confidence interval using pd
    global_gdp_int_error_norm_ci(:,i) = temp_ci(:,1); % collect results
end

% plot
fig_gdp_int = figure;
confplot(1:11,global_gdp_int_error_norm_mean,global_gdp_int_error_norm_mean-global_gdp_int_error_norm_ci(1,:),global_gdp_int_error_norm_ci(2,:)-global_gdp_int_error_norm_mean); 
ylim([0,1])

saveas(fig_gdp_int,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_fig_error_gdp_int.eps','epsc');
clearvars temp* lo i ans h m h_n m_n

%% macro-regional values


% regional average when specific country is left out (we compared the national value to a regional average without the data from that specific country)

macroreg_gdp_leaveout = zeros(size(macroreg_gdp,1),size(national_gdp_fulldata,2)-1,size(national_gdp_fulldata,1));
macroreg_gdp_leaveout(:,1,:) = repmat(macroreg_gdp(:,1),1,1,size(national_gdp_fulldata,1));

for cntry = 1:size(national_gdp_fulldata,1)
    for i = 1:size(national_gdp_fulldata,2)-1
        temp_data = national_gdp_fulldata([1:cntry-1 cntry+1:end],:); % leave out the country in question
        temp_macroreg_id = int8(macroreg_id_sel([1:cntry-1 cntry+1:end],:));
        temp = accumarray(temp_macroreg_id,temp_data(:,i+1),[],@nanmean); % mean regional value
        macroreg_gdp_leaveout(1:12,i+1,cntry) = temp(:,1);
        
    end
    
end

% no data to NaN
macroreg_gdp_leaveout(macroreg_gdp_leaveout == 0) = NaN;

clearvars temp*
clearvars i j 


%% error in extrapolation

% define how many 'rounds' (i.e. max distance to closest value)
n = 23;

national_gdp_extrapol = zeros(size(national_gdp_fulldata));
national_gdp_extrapol(:,1) = national_gdp_fulldata(:,1);

national_gdp_extrapol = repmat(national_gdp_extrapol,1,1,n);

% next lines estimate the HDI with the use of regional trend, using the
% last reported national level HDI as a starting point. 


for n_start = 1:n
    national_gdp_extrapol_start = zeros(1,size(national_gdp_fulldata,2));
    national_gdp_extrapol_start(1,2:1+n_start) = -1;
    
    % the first years
    for i = 1:size(national_gdp_fulldata,1)
        temp_macroreg = macroreg_id_cntry(i,1); % macro-region ID
        temp_cntry_row = i;
        
        [row,col] = find(fliplr(national_gdp_extrapol_start(1,2:end) == -1)); % identify the cells that were extrapolated
        
        if isempty(col) % in case no need to extrapolate
            
        elseif size(col,2) == 26 % in case no data at all
            
            
        else
            
            [row_macroreg,col_macroreg] = find(macroreg_gdp_leaveout(:,1,temp_cntry_row) == temp_macroreg);
            
            % flip
            temp_macroreg_gdp = fliplr(macroreg_gdp_leaveout(row_macroreg,2:end,temp_cntry_row));
            
            temp_macroreg_gdp = temp_macroreg_gdp(1,(col(1,1)-1:end));
            
            
            temp_nat_gdp = fliplr(national_gdp_fulldata(i,2:end));
            
            temp_nat_final_entry = temp_nat_gdp(1,col(1,1)-1);
            temp_diff = temp_nat_final_entry ./ temp_macroreg_gdp(1,1); % ratio between macro-regions value and last reported national value
            
            % scale based on meta-area value
            temp_national_gdp_2015 = temp_diff .* temp_macroreg_gdp(1,2:end);
            
            % fill the matrix
            national_gdp_extrapol(i,2:2+size(col,2)-1,n_start) = fliplr(temp_national_gdp_2015);
        end
    end
end
clearvars temp* i k col* row* 


%% calculate error
national_gdp_extrapol_error = zeros(size(national_gdp_extrapol));
% difference between the reported data and value calculated with regional trends
for n_start = 1:n
    national_gdp_extrapol_error(:,2:1+n_start,n_start) = abs(national_gdp_fulldata(:,2:1+n_start) - national_gdp_extrapol(:,2:1+n_start,n_start));
end

% normalise error
national_gdp_extrapol_error_norm = national_gdp_extrapol_error ./ repmat(national_gdp_fulldata,1,1,n);
national_gdp_extrapol_error_norm(national_gdp_extrapol_error_norm==0) = NaN;

for i = 1:size(national_gdp_extrapol_error_norm,3)
    temp = national_gdp_extrapol_error_norm(:,2:1+i,i);
    
    temp_collect(:,1:i,i) = fliplr( temp);
    
end


for i = 1:size(temp_collect,2)
    temp = temp_collect(:,i,:);
    gdp_extr_error_collect(:,i) = temp(:);
    
end

gdp_extr_error_collect(gdp_extr_error_collect == 0) = NaN;


global_gdp_ext_error_norm_mean = (squeeze( nanmean(gdp_extr_error_collect,1)));

for i = 1:size(gdp_extr_error_collect,2)
    temp_pd = fitdist(gdp_extr_error_collect(:,i),'Normal'); %fit propability distribution
    temp_ci = paramci(temp_pd);% confidence interval using pd
    global_gdp_extr_error_norm_ci(:,i) = temp_ci(:,1); % collect results
end

% plot
fig_gdp_ext = figure;
confplot(1:size(global_gdp_ext_error_norm_mean,2),global_gdp_ext_error_norm_mean,global_gdp_ext_error_norm_mean-global_gdp_extr_error_norm_ci(1,:),global_gdp_extr_error_norm_ci(2,:)-global_gdp_ext_error_norm_mean); 
ylim([0,1])

saveas(fig_gdp_ext,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_fig_error_gdp_ext.eps','epsc');

%% %% distance to error
% the distance to closest value in HDI dataset are now transferred to error
% using the data calculated above

load gdp_distance_to_closest_value.mat % the distance to closest value in GDP dataset was calculated in sub_national_GDP_nov2017_v3.m

load('gdp_spatial_extent.mat','land');

M_maxdist_int = nanmax(map_interp_count,[],3);
M_maxdist_ext = nanmax(map_extrap_count,[],3);
M_maxerror_int = zeros(size(M_maxdist_int),'single');
M_maxerror_ext = zeros(size(M_maxdist_ext),'single');

for i = 1:size(global_gdp_int_error_norm_mean,2)
    temp_error_int = global_gdp_int_error_norm_mean(1,i);
    
    temp_mask_int = M_maxdist_int == i;
    
    M_maxerror_int(temp_mask_int) = temp_error_int;
    
end

for i = 1:size(global_gdp_int_error_norm_mean,2)    
    temp_error_ext = global_gdp_ext_error_norm_mean(1,i); 
    temp_mask_ext = M_maxdist_ext == i;
    M_maxerror_ext(temp_mask_ext) = temp_error_ext;   
end

sea = land == 0;

M_maxerror_int(sea) = NaN;
M_maxerror_ext(sea) = NaN;

%% combine errors
load gdp_subnat_error.mat

% interpolation
M_total_maxerror_int = M_subnat_maxerror_int + M_maxerror_int;
M_total_maxerror_int(M_total_maxerror_int == 0) = -1;

% extrapolation
M_total_maxerror_ext = M_subnat_maxerror_ext + M_maxerror_ext;
M_total_maxerror_ext(M_total_maxerror_ext == 0) = -1;

%% plot max error

% define georeference file

R_00833 = georasterref('RasterSize', [2160 4320], ...
      'RasterInterpretation', 'cells', 'ColumnsStartFrom', 'north', ...
      'LatitudeLimits', [-90 90], 'LongitudeLimits', [-180 180]);


temp_colormap(2:21,:) = cbrewer('seq', 'YlOrRd',20);
temp_colormap(1,:) = [211/255,211/255,211/255];

figure_int_error_map = figure('pos',[10 10 1500 1000]);


temp_plot = M_total_maxerror_int;

axesm ('robinson', 'Frame', 'off', 'Grid', 'off','MapLatLimit',[-90 90]);
set(gca,'CLim', [-0.3/20, 0.3],'xcolor','w','ycolor','w','xtick',[],'ytick',[], 'dataAspectRatio',[1 1 1])
geoshow(temp_plot, R_00833, 'DisplayType', 'surface');

colormap(temp_colormap)
colorbar;

clear temp_plot*

title('Max error in GDP interpolation');

 
saveas(figure_int_error_map,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_fig_gdp_int_maxerror_map.tif','tif');

saveas(figure_int_error_map,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_fig_gdp_int_maxerror_map.eps','epsc');


figure_ext_error_map = figure('pos',[10 10 1500 1000]);


temp_plot = M_total_maxerror_ext;


axesm ('robinson', 'Frame', 'off', 'Grid', 'off','MapLatLimit',[-90 90]);
set(gca,'CLim', [-0.3/20, 0.3],'xcolor','w','ycolor','w','xtick',[],'ytick',[], 'dataAspectRatio',[1 1 1])
geoshow(temp_plot, R_00833, 'DisplayType', 'surface');

colormap(temp_colormap)
colorbar;
clear temp_plot*

title('Max error in GDP extrapolation');
 

saveas(figure_ext_error_map,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_fig_gdp_ext_maxerror_map.tif','tif');

saveas(figure_ext_error_map,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_fig_gdp_ext_maxerror_map.eps','epsc');

