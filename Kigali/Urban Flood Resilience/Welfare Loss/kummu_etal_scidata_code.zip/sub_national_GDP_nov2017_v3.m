%% sub-national GDP

clc
clear
close all
    
cd /Volumes/Kummu_GIS/matlab/global_RBV/
addpath(genpath('/Volumes/Kummu_GIS/matlab/global_RBV/'));

%% import files

% sub-national database
% based on Regions data from 		Gennaioli, Nicola, Rafael LaPorta, Florencio Lopez-de-Silanes, and Andrei Shleifer. 2013. ?Human Capital and Regional Development.? Quarterly Journal of Economics 128 (1): 105-164
% http://scholar.harvard.edu/shleifer/publications?page=1		
% 1950-2010
subnat_gdp = xlsread('/Users/mkummu/Documents/work/publications/varis_al_global_RBV/gdp_region_matrix.xlsx','gdp_matrix','H4:BR1531');

% national database
% based on worldbank development indicators (GDP per capita)
% 1990-2015
national_gdp = xlsread('/Users/mkummu/Documents/work/publications/varis_al_global_RBV/GDP_From_World_Development_Indicators.xlsx','Data','C2:AC220');
national_2015USD = xlsread('/Users/mkummu/Documents/work/publications/varis_al_global_RBV/GDP_From_World_Development_Indicators.xlsx','Data','AH2:AH220');

% macro-regional database
% based on worldbank development indicators (GDP per capita)
% 1990-2015
%meta_gdp = xlsread('/Users/mkummu/Documents/work/publications/varis_al_global_RBV/GDP_From_World_Development_Indicators.xlsx','regional_data','G4:AF10');
macroreg_id_cntry = xlsread('/Users/mkummu/Documents/work/publications/varis_al_global_RBV/GDP_From_World_Development_Indicators.xlsx','Data','AG2:AG220');
%meta_gdp = [[1:7]' meta_gdp];

%% load spatial data 
% prepared in prepare_data_gdp_hdi.m
load gdp_spatial_extent.mat


%% macro-regional analysis
%% collect data for macro-regional gdp 
% macro-regional GDP is calculated as population weighted average GDP per
% capita by using the national GDP
% population data with 5 arc-min from HYDE 3.2 database
load /Volumes/Kummu_GIS/datasets/hyde_3_2/pop_hyde_1981_2015.mat

% sea to NaN
pop_hyde_1981_2015(pop_hyde_1981_2015 == pop_hyde_1981_2015(1,1,1)) = NaN;

% to vector
for i = 10:size(pop_hyde_1981_2015,3)
    temp_pop = pop_hyde_1981_2015(:,:,i);
    v_pop(:,i-9) = temp_pop(land);

end
clearvars pop_h*


v_adm = gdp_cntry(land);
v_adm(v_adm == 0) = 1001;

% collect country IDs
national_pop = accumarray(int32(v_adm),v_adm,[],@mode);

% calculate national population
for i = 1:size(v_pop,2)
    national_pop(:,i+1) = accumarray(int32(v_adm),v_pop(:,i),[],@nansum);
end

% remove all rows with only zeros
national_pop = national_pop(any(national_pop,2),:);
clear national_pop_weigh_gdp
national_pop_weigh_gdp(:,1) = national_pop(1:end-1,1);

for i = 1:size(national_pop,1)
    temp_id = national_pop(i,1); % country ID
    [row,col] = find(national_gdp(:,1) == temp_id); % find correct values
    if isempty(row)
        
    else
    national_pop_weigh_gdp(i,2) = macroreg_id_cntry(row,1);
    national_pop_weigh_gdp(i,3:28) = national_pop(i,2:end) .* national_gdp(row,2:end); % populationa weighted GDP
    end
end


%% calculate macro-regional gdp

% unique values for each macro-region
macroreg_gdp = unique(national_pop_weigh_gdp(:,2))+1;

% identify countries with full dataset
temp_national_gdp = national_pop_weigh_gdp;

% remove rows if even one NaN - only those countries with full data
% coverage will be used to calculate regional average
temp_national_gdp(any(isnan(temp_national_gdp(:,3:end)), 2),:)=[];
temp_national_gdp(any(temp_national_gdp(:,3:end) == 0, 2),:)=[];

% macro-regional gdp calculations
clear temp_national_pop
temp_national_pop(:,1:2) = temp_national_gdp(:,1:2);

for i = 1:size(temp_national_gdp,1)
    temp_id = temp_national_gdp(i,1);
    [row,col] = find(national_pop(:,1) == temp_id);
    if isempty(row)
        
    else
    
    temp_national_pop(i,3:28) = national_pop(row,2:end); % population of the country
    end
end

for i = 1:size(temp_national_gdp,2)-2
    temp_pop = accumarray(temp_national_pop(:,2),temp_national_pop(:,i+2),[],@nansum); % macro-regional population
    temp_weight_gdp = accumarray(temp_national_gdp(:,2),temp_national_gdp(:,i+2),[],@nansum); % weighted GDP
    macroreg_gdp(1:12,i+1) = temp_weight_gdp ./ temp_pop; % calculate average population weighted GDP for each region
    
end

% macro-regional gdp leaving out one country at the time - used for error
% analysis
macro_gdp_leaveout = zeros(size(macroreg_gdp,1),size(temp_national_gdp,2)-1,size(temp_national_gdp,1));
macro_gdp_leaveout(:,1,:) = repmat(macroreg_gdp(:,1),1,1,size(temp_national_gdp,1));

for cntry = 1:size(temp_national_gdp,1)
    for i = 1:size(temp_national_gdp,2)-2
        temp_data_pop = temp_national_pop([1:cntry-1 cntry+1:end],:);
        temp_data_weight_gdp = temp_national_gdp([1:cntry-1 cntry+1:end],:);
        
        temp_pop = accumarray(temp_data_pop(:,2),temp_data_pop(:,i+2),[],@nansum);
        temp_weight_gdp = accumarray(temp_data_weight_gdp(:,2),temp_data_weight_gdp(:,i+2),[],@nansum);
        
        macro_gdp_leaveout(1:12,i+1,cntry) = temp_weight_gdp ./ temp_pop;
        
    end
    
end

save macroreg_gdp.mat macro* temp_national_gdp

clearvars temp* i

%% NATIONAL
%% interpolate national gdp 

% national GDP is based on world development indicators, downloaded
% 20.7.2016 as GDP per capita PPP (in 2011 international dollar)
% expect some special cases, based on CIA fact sheets (see xls)

% scale based on neighboring country data

% Sudan values to South Sudan for year 
national_gdp(179,2:19) = national_gdp(179,20) ./ national_gdp(180,20) .* national_gdp(180,2:19);

% baltic countries - scale based on Belarus for 1990-1994
for i = [60,106,110]
    national_gdp(i,2:6) = national_gdp(i,7) ./ national_gdp(31,7) .* national_gdp(31,2:6);
end


% former yogoslavia - scale based on Yogoslavia GDP per capita estimates
% https://www.quandl.com/data/MADDISON/GDPPC_YUG_NEW-GDP-Per-Capita-of-Former-Yugoslavia-New-Estimate

temp_gdp_former_yogoslavia = [5646.310583	4891.345225	4008.414767	3388.605775	3538.8531	3766.603245	4119.534018];

for i = [21,47,125, 168, 173]
    national_gdp(i,2:6) = national_gdp(i,7) ./ temp_gdp_former_yogoslavia(1,6) .* temp_gdp_former_yogoslavia(1,1:5);
end

clearvars temp*

% interpolate others
national_gdp_interp = zeros(size(national_gdp));
national_gdp_interp(:,1:2) = national_gdp(:,1:2);
national_gdp_interp(1,:) = national_gdp(1,:);

for i = 1:size(national_gdp,1)
    temp = national_gdp(i,2:end);
    
    temp_interp = inpaint_nans(temp,3); % inpaint_nans function used to interpolate the missing values
    
    national_gdp_interp(i,2:end) = temp_interp;
end

clearvars temp* i

%% fill no-data countries (only one: French Southern Territories) with regional average

[row,col] = find(nansum(national_gdp_interp(:,2:end),2) == 0);

temp_macroreg_id = macroreg_id_cntry(row,1);

for i = 1:size(row,1)
    national_gdp_interp(row(i,1),2:end) = macroreg_gdp(temp_macroreg_id(i,1),2:end);
end

clearvars temp* row* col* i ans

%% detect the cells that should extrapolated

% years to be extrapolated at the beginning of the study period
national_gdp_extrapol_start = zeros(size(national_gdp));
national_gdp_extrapol_start(:,1) = national_gdp(:,1);

for i = 1:size(national_gdp,1)
    temp = national_gdp(i,2:end);
    for k = 1:size(temp,2)
        temp_check = temp(1,1:k);
        temp_check(~any(~isnan(temp_check), 2),:) = -1;
        temp_result(1,k) = temp_check(1,k);
    end
    
    national_gdp_extrapol_start(i,2:end) = temp_result;
end
clearvars temp* i k

% years to be extrapolated at the end of the study period
national_gdp_extrapol_end = zeros(size(national_gdp));
national_gdp_extrapol_end(:,1) = national_gdp(:,1);

for i = 1:size(national_gdp,1)
    temp = fliplr(national_gdp(i,2:end));
    for k = 1:size(temp,2)
        temp_check = temp(1,1:k);
        temp_check(~any(~isnan(temp_check), 2),:) = -1;
        temp_result(1,k) = temp_check(1,k);
    end
    
    national_gdp_extrapol_end(i,2:end) = fliplr(temp_result);
end

clearvars temp* i k row* col*


%% extrapolate national values with macro-regional values

national_gdp_extrapol = zeros(size(national_gdp));
national_gdp_extrapol(:,1) = national_gdp(:,1);

% the last years
for i = 1:size(national_gdp,1)
    % meta area id
    temp_macroreg_area = macroreg_id_cntry(i,1);
    % find where cells to be extrapolated are located
    [row,col] = find(national_gdp_extrapol_end(i,:) == -1);
    
    if isempty(col)
        % nothing will happen
    else
        % find correct macro-region
        [row_macroreg,col_macroreg] = find(macroreg_gdp(:,1) == temp_macroreg_area);
                    
        temp_gdp = macroreg_gdp(row_macroreg,(col(1,1)-1:end));
        
        temp_national_final_entry = national_gdp_interp(i,col(1,1)-1);
        % ratio between last national value and corresponding year macro-regional value
        temp_diff = temp_national_final_entry ./ temp_gdp(1,1);
        
        % scale based on macro-regional value
        temp_national_gdp_2015 = temp_diff .* temp_gdp(1,2:end);
        
        % fill the matrix
        national_gdp_extrapol(i,col(1,1):end) = temp_national_gdp_2015;
    end
end
clearvars temp* i k

% the first years
for i = 1:size(national_gdp,1)
    temp_macroreg_area = macroreg_id_cntry(i,1);
    
    [row,col] = find(fliplr(national_gdp_extrapol_start(i,2:end)) == -1);
    
    if isempty(col) % in case no need to extrapolate
        
    elseif size(col,2) == 26 % in case no data at all, use regional value
        national_gdp_extrapol(i,2:end) = macroreg_gdp(row_macroreg,2:end);
        
    else
                
        [row_macroreg,col_macroreg] = find(macroreg_gdp(:,1) == temp_macroreg_area);
                
        % flip  
        temp_macroreg_gdp = fliplr(macroreg_gdp(row_macroreg,2:end));
        
        temp_macroreg_gdp = temp_macroreg_gdp(1,(col(1,1)-1:end));
        
        
        temp_nat_gdp = fliplr(national_gdp_interp(i,2:end));
        
        temp_nat_final_entry = temp_nat_gdp(1,col(1,1)-1);
        % ratio between last national value and corresponding year macro-regional value
        temp_diff = temp_nat_final_entry ./ temp_macroreg_gdp(1,1);
        
        % scale based on macro-regional value
        temp_national_gdp_2015 = temp_diff .* temp_macroreg_gdp(1,2:end);
        
        % fill the matrix
        national_gdp_extrapol(i,2:2+size(col,2)-1) = fliplr(temp_national_gdp_2015);
    end
end
clearvars temp* i k col* row* 

%% combine interpolated and extrapolated data
national_gdp_filled = zeros(size(national_gdp));
national_gdp_filled(:,1) = national_gdp(:,1);

national_gdp_filled(:,2:end) = national_gdp_interp(:,2:end);

temp_filled = national_gdp_extrapol(:,:);

% fill the values from extrapolated dataset to the one that was
% interpolated
national_gdp_filled(temp_filled > 0) = temp_filled(temp_filled > 0);

clearvars temp*

%% change base year to 2011, for those countries with base year of 2015

[row,col] = find(national_2015USD == 1);

temp_national_gdp_2015 = national_gdp_filled(row,:);
temp_ratio = temp_national_gdp_2015(:,2:end) ./ repmat(temp_national_gdp_2015(:,23),1,26);
temp_national_gdp_2011 = temp_ratio .* (0.9411 .* repmat(temp_national_gdp_2015(:,23),1,26)); % dollar value in 2011 was 0.9490 in relation to one in 2015 (calculated by using constact and current GDP per capita PPP data of World Bank)

% put the values back to the matrix
national_gdp_filled(row,2:end) = temp_national_gdp_2011;

clearvars temp* row col


%% distance to closest reported value - for error calculations

% interpolation
temp_interp = national_gdp;
temp_interp(or(national_gdp_extrapol_start == -1,national_gdp_extrapol_end == -1)) = -1;

% extrapolation
temp_extrap = temp_interp;

% detect the cells that were extrapolated
temp = temp_extrap(:,2:end);
temp(temp>-1) = 1;
temp(temp==-1) = 0;
temp(isnan(temp)) = 1;
temp_extrap(:,2:end) = temp;

% detect the cells that were interpolated
temp = temp_interp(:,2:end);
temp(temp>-5) = 1;
temp(isnan(temp)) = 0;
temp_interp(:,2:end) = temp;

% count the distance to closest available value with bwdist function
interp_count = temp_interp;
extrap_count = temp_extrap;

for i = 1:size(temp_extrap,1)
    interp_count(i,2:end) = bwdist(temp_interp(i,2:end));
    extrap_count(i,2:end) = bwdist(temp_extrap(i,2:end));   
end

clear temp* row col i ans

%% cntry data to raster

map_cntry = single(gdp_cntry_all);
map_interp_count = zeros(size(map_cntry,1),size(map_cntry,2),size(extrap_count,2)-1,'single');
map_extrap_count = zeros(size(map_cntry,1),size(map_cntry,2),size(extrap_count,2)-1,'single');

for yr = 2:size(extrap_count,2)
    
    temp_map_interp = zeros(size(map_cntry),'single'); % create empty map
    temp_map_extrap = zeros(size(map_cntry),'single'); % create empty map
    map_cntry_mask = single(map_cntry);
      
    for cntry = 1:size(extrap_count,1)
        cntry_id = extrap_count(cntry,1);      
        cntry_logical = map_cntry_mask == cntry_id; % create a mask for a country in question
        
        temp_map1 = zeros(size(map_cntry),'single');
        temp_map1(cntry_logical) = single(interp_count(cntry,yr)); % find correct data
        
        temp_map_interp = temp_map_interp + temp_map1; 
        
        temp_map2 = zeros(size(map_cntry),'single'); 
        temp_map2(cntry_logical) = single(extrap_count(cntry,yr));
        temp_map_extrap = temp_map_extrap + temp_map2;
    end
    
    map_interp_count(:,:,yr-1) = temp_map1 + temp_map_interp; % collect values to final map
    map_extrap_count(:,:,yr-1) = temp_map2 + temp_map_extrap; % collect values to final map
    clearvars temp*
end

save gdp_distance_to_closest_value.mat *count 


%% SUB-NATIONAL: 

%% interpolation

% 1990: row 43
% 1995: row 48
% etc


subnat_gdp_interp = zeros(size(subnat_gdp));
subnat_gdp_interp(:,1:2) = subnat_gdp(:,1:2);
subnat_gdp_interp(1,:) = subnat_gdp(1,:);

for i = 2:size(subnat_gdp,1)
    temp = subnat_gdp(i,3:end);
    
    temp_interp = inpaint_nans(temp,3); % interpolate missing values with inpaint_nans function
    
    subnat_gdp_interp(i,3:end) = temp_interp;
end

clearvars temp* i

%% detect the cells that should extrapolated

% years to be extrapolated at the beginning of the study period
subnat_gdp_extrapol_start = zeros(size(subnat_gdp));
subnat_gdp_extrapol_start(:,1:2) = subnat_gdp(:,1:2);
subnat_gdp_extrapol_start(1,:) = subnat_gdp(1,:);

for i = 2:size(subnat_gdp,1)
    temp = subnat_gdp(i,3:end);
    for k = 1:size(temp,2)
        temp_check = temp(1,1:k);
        temp_check(~any(~isnan(temp_check), 2),:) = -1;
        temp_result(1,k) = temp_check(1,k);
    end
    
    subnat_gdp_extrapol_start(i,3:end) = temp_result;
end
clearvars temp* i k

% years to be extrapolated at the end of the study period
subnat_gdp_extrapol_end = zeros(size(subnat_gdp));
subnat_gdp_extrapol_end(:,1:2) = subnat_gdp(:,1:2);
subnat_gdp_extrapol_end(1,:) = subnat_gdp(1,:);

for i = 2:size(subnat_gdp,1)
    temp = fliplr(subnat_gdp(i,3:end));
    for k = 1:size(temp,2)
        temp_check = temp(1,1:k);
        temp_check(~any(~isnan(temp_check), 2),:) = -1;
        temp_result(1,k) = temp_check(1,k);
    end
    
    subnat_gdp_extrapol_end(i,3:end) = fliplr(temp_result);
end

clearvars temp* i k

%% distance to closest reported value - for error calculations

% interpolation
temp_interp = subnat_gdp(2:end,[1:2 43:end]);
temp_interp(or(subnat_gdp_extrapol_start(2:end,[1:2 43:end]) == -1,subnat_gdp_extrapol_end(2:end,[1:2 43:end]) == -1)) = -1;

% extrapolation
temp_extrap = temp_interp;

temp = temp_extrap(:,3:end);
temp(temp>-1) = 1;
temp(temp==-1) = 0;
temp(isnan(temp)) = 1;
temp_extrap(:,3:end) = temp;


temp = temp_interp(:,3:end);
temp(temp>-5) = 1;
temp(isnan(temp)) = 0;
temp_interp(:,3:end) = temp;

interp_count = temp_interp;
extrap_count = temp_extrap;

% add five last year, as no sub-national data for 2011-2015
interp_count = [interp_count ones(size(interp_count,1),5)];
extrap_count = [extrap_count zeros(size(interp_count,1),5)];

for i = 1:size(temp_extrap,1)
    interp_count(i,3:end) = bwdist(interp_count(i,3:end));
    extrap_count(i,3:end) = bwdist(extrap_count(i,3:end));
   
end

clear temp* row col i ans

% to map

map_subnat = single(gdp_subnat_all_cut);
map_interp_count = zeros(size(map_subnat,1),size(map_subnat,2),size(extrap_count,2)-2,'single');
map_extrap_count = zeros(size(map_subnat,1),size(map_subnat,2),size(extrap_count,2)-2,'single');

for yr = 3:size(extrap_count,2)
    
    temp_map_interp = zeros(size(map_subnat),'single'); % create empty maps
    temp_map_extrap = zeros(size(map_subnat),'single'); % create empty maps
    map_subnat_mask = single(map_subnat);
      
    for subnat = 1:size(extrap_count,1)
        temp_id = extrap_count(subnat,2);   % subnational ID    
        temp_logical = map_subnat_mask == temp_id; % create mask
        
        temp_map1 = zeros(size(map_subnat),'single');
        temp_map1(temp_logical) = single(interp_count(subnat,yr));
        
        temp_map_interp = temp_map_interp + temp_map1;
        
        temp_map2 = zeros(size(map_subnat),'single');
        temp_map2(temp_logical) = single(extrap_count(subnat,yr));
        temp_map_extrap = temp_map_extrap + temp_map2;
    end
    
    map_interp_count(:,:,yr-2) = temp_map_interp;
    map_extrap_count(:,:,yr-2) = temp_map_extrap;
    clearvars temp*
    X = ['Current year: ',num2str(yr),'.']; 
    disp(X) % display the progress
end

save subnat_gdp_distance_to_closest_value.mat *count 

%% extrapolate with national values

% temporal trend from national values used to extrapolate the sub-national
% values

subnat_gdp_extrapol = zeros(size(subnat_gdp));
subnat_gdp_extrapol(:,1:2) = subnat_gdp(:,1:2);
subnat_gdp_extrapol(1,:) = subnat_gdp(1,:);

% the last years
for i = 2:size(subnat_gdp,1)
    temp_cntry = subnat_gdp_extrapol_end(i,1);
    
    [row,col] = find(subnat_gdp_extrapol_end(i,:) == -1);
    
    if isempty(col) % if no years to extrapolate before 2010, then we extrapolated years from 2010 onwards
        col = 64;
        [row_cntry,col_cntry] = find(national_gdp_filled(:,1) == temp_cntry);
        % 2010 --> col 22 in national
        % 2010 --> col 63 in regional
            
        temp_gdp = national_gdp_filled(row_cntry,(col(1,1)-41-1:end)); % find correct national values
               
        % last data entry
        temp_subnat_final_entry = subnat_gdp_interp(i,col(1,1)-1);
        temp_diff = temp_subnat_final_entry ./ temp_gdp(1,1); % difference between last sub-national data entry and corresponding national value
        
        % scale based on national value
        temp_subnat_gdp = temp_diff .* temp_gdp(1,2:end);
        
        % fill the matrix
        subnat_gdp_extrapol(i,col:68) = temp_subnat_gdp;
    else % missing values at the end of the study period, before 2010
                
        [row_cntry,col_cntry] = find(national_gdp_filled(:,1) == temp_cntry);
        % 2010 --> col 22 in national
        % 2010 --> col 63 in regional
            
        temp_gdp = national_gdp_filled(row_cntry,(col(1,1)-41-1:end)); % find correct national values
        
        temp_subnat_final_entry = subnat_gdp_interp(i,col(1,1)-1);
        temp_diff = temp_subnat_final_entry ./ temp_gdp(1,1); % difference between last sub-national data entry and corresponding national value
        
        % scale based on national value
        temp_subnat_gdp = temp_diff .* temp_gdp(1,2:end);
        
        % fill the matrix
        subnat_gdp_extrapol(i,col:68) = temp_subnat_gdp;
    end
end
clearvars temp* i k

% the first years
for i = 2:size(subnat_gdp,1)
    temp_cntry = subnat_gdp_extrapol_start(i,1);
    % flip (to make it easier to extrapolate) and select only 1990-2010
    [row,col] = find(fliplr(subnat_gdp_extrapol_start(i,43:63)) == -1);
    
    if isempty(col)
        
    else
                
        [row_cntry,col_cntry] = find(national_gdp_filled(:,1) == temp_cntry);
        % 2010 --> col 22 in national
        % 2010 --> col 63 in regional
        
        % 1990 --> col 2 in national
        % 1990 --> col 43 in regional
        
        % flip and select only 1990-2010    
        temp_gdp = fliplr(national_gdp_filled(row_cntry,2:22));
        
        temp_gdp = temp_gdp(1,(col(1,1)-1:end)); % find correct national values
                
        temp_reg = fliplr(subnat_gdp_interp(i,43:63));
        
        temp_subnat_final_entry = temp_reg(1,col(1,1)-1);
        temp_diff = temp_subnat_final_entry ./ temp_gdp(1,1); % difference between last sub-national data entry and corresponding national value
        
        % scale based on national value
        temp_subnat_gdp = temp_diff .* temp_gdp(1,2:end);
        
        %temp_reg(1,col(1,1):end) = temp_reg_gdp;
        % fill the matrix
        subnat_gdp_extrapol(i,43:43+size(col,2)-1) = fliplr(temp_subnat_gdp);
    end
end
clearvars temp* i k col* row* 


%% combine interpolated and extrapolated data

subnat_gdp_filled = zeros(size(subnat_gdp,1),size(national_gdp,2)+1);
subnat_gdp_filled(:,1:2) = subnat_gdp(:,1:2);
subnat_gdp_filled(1,3:end) = 1990:2015;

% first interpolated values
subnat_gdp_filled(2:end,3:3+20) = subnat_gdp_interp(2:end,43:end);

% from extrapolated, select the study area temporal coverage
temp_filled = subnat_gdp_extrapol(:,[1:2 43:end]);

% fill the extrapolated values to the data table
subnat_gdp_filled(temp_filled > 0) = temp_filled(temp_filled > 0);

clearvars temp*

%% ratio between sub-national data and national data
% instead of using sub-national data directly, we used that to scale the
% national data, in order to consistent with the countries with only
% national data available. Further, sub-national data was in constant US
% dollars 2005 and national data in constant US dollars 2011 - by using scaling
% we avoid any inconsistency between the datasets

map_subnat = single(gdp_subnat_all_cut);
map_cntry = single(gdp_cntry_all);

% read population data
load /Volumes/Kummu_GIS/datasets/hyde_3_2/pop_hyde_1981_2015.mat

% data to vectors
for i = 10:size(pop_hyde_1981_2015,3)
    temp_pop = pop_hyde_1981_2015(:,:,i);
    v_pop(:,i-9) = temp_pop(land);

end

v_subnat = map_subnat(land);
v_subnat(v_subnat == 0) = 1600;
v_cntry = map_cntry(land);

clearvars temp_* i

% population in each sub-national unit

unique(v_cntry);

subnat_pop = accumarray(int16(v_subnat),int16(v_subnat),[],@nanmean); % subnational ID
national_pop = accumarray(int16(v_cntry),int16(v_cntry),[],@nanmean); % country ID
for i = 1:size(v_pop,2)
    temp_pop = v_pop(:,i);
    
    subnat_pop(:,i+1) = accumarray(int16(v_subnat),temp_pop,[],@nansum); % population aggregated to each subnational unit
    national_pop(:,i+1) = accumarray(int16(v_cntry),temp_pop,[],@nansum); % population aggregated to each country
end

% population weighted GDP

subnat_weighted_gdp = zeros(size(subnat_gdp_filled));
subnat_weighted_gdp(:,1:2) = subnat_gdp_filled(:,1:2);
subnat_weighted_gdp(1,:) = subnat_gdp_filled(1,:);

subnat_pop_correct_order = zeros(size(subnat_gdp_filled));
subnat_pop_correct_order(:,1:2) = subnat_gdp_filled(:,1:2);
subnat_pop_correct_order(1,:) = subnat_gdp_filled(1,:);

for i = 1:size(subnat_gdp,1)-1
    temp_subnat_id = subnat_gdp_filled(i+1,2); % ID
    
    [row,col] = find(subnat_pop(:,1) == temp_subnat_id); % % locate row and col of the corresponding ID
    
    if isempty(row)
    
    else
    temp_pop = subnat_pop(row,2:end); % find corresponding pop
    temp_gdp = subnat_gdp_filled(i+1,3:end); % find corresponding GDP
    
    subnat_pop_correct_order(i+1,3:end) = temp_pop; % population to data table
    subnat_weighted_gdp(i+1,3:end) = temp_pop .* temp_gdp; % pop*GDP to data table
    
    end
end

% calculate the gdp weighted with population, in order to calculate the
% national values for gdp based on sub-national values. This is the used to
% calculate the final sub-national gdp

national_weighted_gdp_from_reg_gdp = accumarray(int16(subnat_weighted_gdp(2:end,1)),int16(subnat_weighted_gdp(2:end,1)),[],@nanmean);
national_pop_from_reg_pop= accumarray(int16(subnat_weighted_gdp(2:end,1)),int16(subnat_weighted_gdp(2:end,1)),[],@nanmean);

for i = 3:size(subnat_pop,2)+1
    
    temp_weighted_gdp = subnat_weighted_gdp(:,i);
    temp_pop = subnat_pop_correct_order(:,i);
    
    national_weighted_gdp_from_reg_gdp(:,i-1) = accumarray(int16(subnat_weighted_gdp(2:end,1)),temp_weighted_gdp(2:end,1),[],@nansum);
    national_pop_from_reg_pop(:,i-1) = accumarray(int16(subnat_weighted_gdp(2:end,1)),temp_pop(2:end,1),[],@nansum);
end

national_gdp_from_subnat(:,1) = national_pop_from_reg_pop(:,1);
national_gdp_from_subnat(:,2:27) = national_weighted_gdp_from_reg_gdp(:,2:end) ./ national_pop_from_reg_pop(:,2:end);

% calculate how much sub-national gdp differs from this national gdp

subnat_gdp_ratio = zeros(size(subnat_gdp_filled));
subnat_gdp_ratio(:,1:2) = subnat_gdp_filled(:,1:2);
subnat_gdp_ratio(1,:) = subnat_gdp_filled(1,:);

for i = 1:size(subnat_gdp,1)-1
    temp_subnat_id = subnat_gdp_filled(i+1,2); % subnational ID
    temp_nat_id = subnat_gdp_filled(i+1,1); % national ID
    
    [row,col] = find(national_gdp_from_subnat(:,1) == temp_nat_id); % locate row and col of the corresponding ID
    
    if isempty(row)
    
    else
    temp_gdp_national = national_gdp_from_subnat(row,2:end);
    temp_gdp_subnat = subnat_gdp_filled(i+1,3:end);
    temp_gdp_ratio = temp_gdp_subnat ./ temp_gdp_national; % calculate the ratio
    
    subnat_gdp_ratio(i+1,3:end) = temp_gdp_ratio;
    
    end
    clearvars temp* i col row
end 


% calculate sub-national GDP based on 2011 values from national gdp data

subnat_gdp_scaled = zeros(size(subnat_gdp_filled));
subnat_gdp_scaled(:,1:2) = subnat_gdp_filled(:,1:2);
subnat_gdp_scaled(1,:) = subnat_gdp_filled(1,:);

for i = 1:size(subnat_gdp,1)-1
    
    temp_nat_id = subnat_gdp_filled(i+1,1); % ID
    
    [row,col] = find(national_gdp_filled(:,1) == temp_nat_id); % locate row and col of the corresponding ID
    
    if isempty(row)
    
    else
    temp_gdp_national = national_gdp_filled(row,2:end); % find corresponding national value
    temp_gdp_subnat_ratio = subnat_gdp_ratio(i+1,3:end); % find corresponding ratio between national and sub-national value
    temp_gdp_subnat = temp_gdp_subnat_ratio .* temp_gdp_national; % calculate scaled GDP at subnational level
    
    subnat_gdp_scaled(i+1,3:end) = temp_gdp_subnat; % store to correct data table
    
    end
    clearvars temp* i col row
end 


%% put to map

map_subnat = single(gdp_subnat_all_cut);
map_cntry = single(gdp_cntry_all);

% create mask for sea
sea = land == 0;

map_subnat_gdp = zeros(size(map_subnat,1),size(map_subnat,2),size(subnat_gdp_filled,2)-2,'single');

for yr = 3:size(subnat_gdp_filled,2)
    
    % subnational data to map
    temp_map2 = zeros(size(map_subnat),'single');
    parfor i = 2:size(subnat_gdp,1)
        subnat_id = subnat_gdp(i,2); % subnational ID
        subnat_logical = map_subnat == subnat_id; % mask for subnational unit in question
        
        
        temp_map = zeros(size(map_subnat),'single'); % create empty map
        temp_map(subnat_logical) = single(subnat_gdp_scaled(i,yr)); % put right value to the masked area
        
        temp_map2 = temp_map2 + temp_map;
    end
    
    % national data to map
    temp_map3 = zeros(size(map_subnat),'single');
    map_cntry_mask = map_cntry;
    map_cntry_mask(temp_map2 > 0) = 0;
    map_cntry_mask = single(map_cntry_mask); 
    
    for cntry = 1:size(national_gdp_filled,1)
        cntry_id = national_gdp_filled(cntry,1);  % country ID    
        cntry_logical = map_cntry_mask == cntry_id; % mask for a country in questions
        
        temp_map = zeros(size(map_cntry),'single'); % create empty map
        temp_map(cntry_logical) = single(national_gdp_filled(cntry,yr-1)); % put right value to the masked area
        
        temp_map3 = temp_map3 + temp_map;
    end
    
    map_subnat_gdp(:,:,yr-2) = temp_map2 + temp_map3; % combine subnational and national data
    clearvars temp*
end


% no data to -9
map_subnat_gdp(isnan(map_subnat_gdp)) = -9;

% sea to NaN
map_subnat_gdp(repmat(sea,1,1,size(map_subnat_gdp,3))) = NaN;

save subnational_gdp.mat map*

%% plot results

load subnational_gdp.mat

% georeference file
R_00833 = georasterref('RasterSize', [2160 4320], ...
      'RasterInterpretation', 'cells', 'ColumnsStartFrom', 'north', ...
      'LatitudeLimits', [-90 90], 'LongitudeLimits', [-180 180]);

% titles
Title_gdp = {'GDP 1990', 'GDP 1995', 'GDP 2000','GDP 2005','GDP 2010', 'GDP 2015'};

% colormap
temp_colormap = flipud(cbrewer('div', 'Spectral',21));

% create empty figure
figure_gdp_percap_map = figure('pos',[10 10 1500 3000]);

for yr = 1:6
    
        subtightplot(3,2,yr,[0.1 0.1])
        temp_plot = map_subnat_gdp(:,:,1+5*(yr-1));
              
        axesm ('robinson', 'Frame', 'off', 'Grid', 'off','MapLatLimit',[-90 90]);
        set(gca,'CLim', [0, 50000],'xcolor','w','ycolor','w','xtick',[],'ytick',[], 'dataAspectRatio',[1 1 1])
        geoshow(temp_plot, R_00833, 'DisplayType', 'surface');  
        
        colormap(temp_colormap)
        colorbar;
        
        clear temp_plot*
        
        title(Title_gdp(yr));
    
end

% save figure

saveas(figure_gdp_percap_map,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_fig2_gdp_percap_v6.tif','tif');

saveas(figure_gdp_percap_map,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_fig2_gdp_percap_v6.eps','epsc');
%% GDP total - 5 arc-min
load subnational_gdp.mat
load '/Volumes/Kummu_GIS/datasets/hyde_3_2/pop_hyde_1981_2015.mat'

pop_hyde_1981_2015(isnan(pop_hyde_1981_2015)) = 0;

% total GDP; GDP per capita multiplied with population
map_subnat_gdp_total = pop_hyde_1981_2015(:,:,10:end) .* map_subnat_gdp;

%plot


R_00833 = georasterref('RasterSize', [2160 4320], ...
      'RasterInterpretation', 'cells', 'ColumnsStartFrom', 'north', ...
      'LatitudeLimits', [-90 90], 'LongitudeLimits', [-180 180]);

Title_gdp = {'GDP 1990', 'GDP 1995', 'GDP 2000','GDP 2005','GDP 2010', 'GDP 2015'};

temp_colormap = flipud(cbrewer('div', 'Spectral',21));
temp_colormap(1,:) = [211/255,211/255,211/255];

range_high = 10*10^7;
range_low = -range_high/20;


figure_gdp_total_map = figure('pos',[10 10 1500 3000]);

for yr = 1:6
    
        subtightplot(3,2,yr,[0.1 0.1])
        temp_plot = map_subnat_gdp_total(:,:,1+5*(yr-1));
        temp_plot(temp_plot == 0) = range_low;
        
        axesm ('robinson', 'Frame', 'off', 'Grid', 'off','MapLatLimit',[-90 90]);
        set(gca,'CLim', [range_low, range_high],'xcolor','w','ycolor','w','xtick',[],'ytick',[], 'dataAspectRatio',[1 1 1])
        geoshow(temp_plot, R_00833, 'DisplayType', 'surface');  
        
        colormap(temp_colormap)
        colorbar;
        
        clear temp_plot*
        
        title(Title_gdp(yr));
    
end


saveas(figure_gdp_total_map,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_fig3_gdp_v6.tif','tif');


saveas(figure_gdp_total_map,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_fig3_gdp_v6.eps','epsc');

%% save GDP

save subnational_gdp.mat map*

%% GDP total - 30 arc-sec
load subnational_gdp.mat

pop_30arcsec = geotiffread('/Volumes/Kummu_GIS/datasets/pop_global_GHS_by_JRC/ghs90_wgs/ghs90_wgs1_full_extent.tif');
pop_30arcsec(:,:,2) = geotiffread('/Volumes/Kummu_GIS/datasets/pop_global_GHS_by_JRC/ghs00_wgs1/ghs00_wgs1_full_extent.tif');
pop_30arcsec(:,:,3) = geotiffread('/Volumes/Kummu_GIS/datasets/pop_global_GHS_by_JRC/ghs15_wgs1/ghs15_wgs1_full_extent.tif');

pop_30arcsec(pop_30arcsec<0) = 0;

% area for each grid cell
area_30arcsec = single(areacell(0.0083333333));


for i = 1:3
    temp_pop = pop_30arcsec(:,:,i);
    popcount_30arcsec(:,:,i) = temp_pop .* area_30arcsec;
end

clearvars area* pop_*
% imagesc(popcount_30arcsec(:,:,3));
% nansum(nansum(popcount_30arcsec(:,:,:)));


% expand gdp (1990 - 1; 2000 - 11; 2015 - 26)
gdp_total_30arcsec = zeros(21600,43200,3,'single');
i_pos = [1,11,26];
for i = 1:3
    temp_gdp = map_subnat_gdp(:,:,i_pos(i));  
    temp_ones = ones(10,10);
    gdp_total_30arcsec(:,:,i) = kron(temp_gdp,temp_ones) .* popcount_30arcsec(:,:,i);
end


save gdp_total_30arcsec.mat gdp_total_30arcsec

%% Plot total GDP with 30 arc sec resolution


R_000833 = georasterref('RasterSize', [21600 43200], ...
      'RasterInterpretation', 'cells', 'ColumnsStartFrom', 'north', ...
      'LatitudeLimits', [-90 90], 'LongitudeLimits', [-180 180]);


Title_gdp = {'GDP 1990', 'GDP 2000','GDP 2015'};

temp_colormap = flipud(cbrewer('div', 'Spectral',21));
temp_colormap(1,:) = [211/255,211/255,211/255];

range_high = 40*10^6;
range_low = -range_high/20;


figure_gdp_total_map = figure('pos',[10 10 1500 1500]);

for yr = 1:3
    
        subtightplot(2,2,yr,[0.1 0.1])
        temp_plot = gdp_total_30arcsec(7500:9000,31000:32500,yr); % only part of the study area
        temp_plot(temp_plot == 0) = range_low;
        b = imagesc(temp_plot);
        set(b,'AlphaData',~isnan(temp_plot))
        
        clear temp_plot*
        colormap(temp_colormap)
        set(gca, 'CLim', [range_low, range_high],'xtick',[],'ytick',[],'dataAspectRatio',[1 1 1]);
        colorbar;
 
        title(Title_gdp(yr));
    
end


saveas(figure_gdp_total_map,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_fig9_gdp_30arcsec_v6.tif','tif');


saveas(figure_gdp_total_map,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_fig9_gdp_30arcsec_v6.eps','epsc');




%% pedigree of results

% subnational

subnat_gdp_accuracy = zeros(size(subnat_gdp,1),size(national_gdp,2)+1);
subnat_gdp_accuracy(:,1:2) = subnat_gdp(:,1:2);
subnat_gdp_accuracy(1,3:end) = 1990:2015;


% 1 = observed
% 2 = interpolated
% 3 = extrapolated

temp = subnat_gdp(:,[1:2 43:end]);
subnat_gdp_accuracy(temp > 0) = 1;

temp_end = subnat_gdp_extrapol_end(:,[1:2 43:end]);
temp_start = subnat_gdp_extrapol_start(:,[1:2 43:end]);
subnat_gdp_accuracy(or(temp_end == -1, temp_start == -1)) = 3;

% 2011-2015 to exptrapolated (3)
subnat_gdp_accuracy(2:end,24:end) = 3;

% other value to interpolated (2)
subnat_gdp_accuracy(subnat_gdp_accuracy==0) = 2;


% national

national_gdp_accuracy = xlsread('/Users/mkummu/Documents/work/publications/varis_al_global_RBV/GDP_From_World_Development_Indicators.xlsx','Data','C2:AC220');

national_gdp_accuracy(national_gdp == -9) = -1;

% interpolated
national_gdp_accuracy(and(isnan(national_gdp_accuracy),national_gdp_extrapol==0)) = 6;
% extrapolated
national_gdp_accuracy(and(isnan(national_gdp_accuracy),national_gdp_extrapol>0)) = 7;


% other values
national_gdp_accuracy(national_gdp_accuracy > 7) = 5;
national_gdp_accuracy(:,1) = national_gdp(:,1);


%% put to map 
% see notation above

map_subnat_accuracy = zeros(size(map_subnat,1),size(map_subnat,2),size(subnat_gdp_accuracy,2)-2,'int8');

for yr = 3:size(subnat_gdp_accuracy,2)
    temp_map2 = zeros(size(map_subnat),'int8');
    parfor i = 2:size(subnat_gdp,1)
        subnat_id = subnat_gdp(i,2);
        subnat_logical = map_subnat == subnat_id;
        
        
        temp_map = zeros(size(map_subnat),'int8');
        temp_map(subnat_logical) = int8(subnat_gdp_accuracy(i,yr));
        
        temp_map2 = temp_map2 + temp_map;
    end
    
    temp_map3 = zeros(size(map_subnat),'int8');
    map_cntry_mask = map_cntry;
    map_cntry_mask(temp_map2 > 0) = 0;
    map_cntry_mask = single(map_cntry_mask);
    
    for cntry = 1:size(national_gdp,1)
        cntry_id = national_gdp(cntry,1);
        cntry_logical = map_cntry_mask == cntry_id;
        
        temp_map = zeros(size(map_cntry),'int8');
        temp_map(cntry_logical) = int8(national_gdp_accuracy(cntry,yr-1));
        
        temp_map3 = temp_map3 + temp_map;
    end
    
    map_subnat_accuracy(:,:,yr-2) = temp_map2 + temp_map3;
    clearvars temp*
end

% no data to -9
map_subnat_accuracy(isnan(map_subnat_accuracy)) = -9;

% sea to NaN
sea = land == 0;
map_subnat_accuracy = single(map_subnat_accuracy);

map_subnat_accuracy(repmat(sea,1,1,size(map_subnat_accuracy,3))) = NaN;


save subnational_gdp_accuracy.mat map*_accu*

%% plot accuracy
load subnational_gdp_accuracy.mat


R_00833 = georasterref('RasterSize', [2160 4320], ...
      'RasterInterpretation', 'cells', 'ColumnsStartFrom', 'north', ...
      'LatitudeLimits', [-90 90], 'LongitudeLimits', [-180 180]);


Title_accuracy = {'Accuracy 1990', 'Accuracy 1995', 'Accuracy 2000','Accuracy 2005','Accuracy 2010', 'Accuracy 2015'};

temp_colormap(2:8,:) = flipud(cbrewer('div', 'RdYlBu',7));
temp_colormap(4,:) = [179/255,217/255,255/255];
temp_colormap(1,:) = [211/255,211/255,211/255];

test_rgb = 255*temp_colormap;

figure_accuracy_map = figure('pos',[10 10 1500 3000]);

for yr = 1:6
    
        subtightplot(3,2,yr,[0.1 0.1])
        temp_plot = map_subnat_accuracy(:,:,1+5*(yr-1));
              
        axesm ('robinson', 'Frame', 'off', 'Grid', 'off','MapLatLimit',[-90 90]);
        set(gca,'CLim', [-0.5, 7.5],'xcolor','w','ycolor','w','xtick',[],'ytick',[], 'dataAspectRatio',[1 1 1])
        geoshow(temp_plot, R_00833, 'DisplayType', 'surface');  
        
        colormap(temp_colormap)
        colorbar;
        
        clear temp_plot*
        
        title(Title_accuracy(yr));
    
end


saveas(figure_accuracy_map,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_fig5_gdp_accuracy_v6.tif','tif');


saveas(figure_accuracy_map,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_fig5_gdp_accuracy_v6.eps','epsc');
