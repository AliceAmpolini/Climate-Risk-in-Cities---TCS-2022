%% spatial data preparation - sub-national HDI and GDP

clc
clear
close all
    
cd /Volumes/Kummu_GIS/matlab/global_RBV/
addpath(genpath('/Volumes/Kummu_GIS/matlab/global_RBV/'));

%% remove overlap from sub-national datasets

hdi_subnat_nuts = imread('/Volumes/Kummu_GIS/matlab/global_RBV/reg_hdi/temp/hdi_reg_nuts.tif');
hdi_subnat_other = imread('/Volumes/Kummu_GIS/matlab/global_RBV/reg_hdi/temp/hdi_reg_other.tif');

% remove overlap by setting other dataset to zero, where values in nuts

hdi_subnat_other(hdi_subnat_nuts>0) = 0;

% write to geotiff
R_5arcmin = georasterref('RasterSize', [2160 4320], ...
      'RasterInterpretation', 'cells', 'ColumnsStartFrom', 'north', ...
      'LatitudeLimits', [-90 90], 'LongitudeLimits', [-180 180]);

geotiffwrite('/Volumes/Kummu_GIS/matlab/global_RBV/reg_hdi/temp/hdi_subnat_other_no_overlap.tif',hdi_subnat_other,R_5arcmin);

clearvars hdi_* R_*
%% GDP

% read data
gdp_subnat_all = imread('/Volumes/Kummu_GIS/matlab/global_RBV/reg_gdp/temp/gdp_reg_all1.tif');
gdp_cntry_all = imread('/Volumes/Kummu_GIS/matlab/global_RBV/reg_gdp/temp/gdp_cntr_all1.tif');

gdp_subnat = imread('/Volumes/Kummu_GIS/matlab/global_RBV/reg_gdp/gdp_regions.tif');
gdp_cntry = imread('/Volumes/Kummu_GIS/matlab/global_RBV/reg_gdp/gdp_country3.tif');
imagesc(gdp_cntry)
temp_gdp_list_cntrys_with_subnat_data = xlsread('/Users/mkummu/Documents/work/publications/varis_al_global_RBV/gdp_region_matrix.xlsx','gdp_matrix','H4:H1531');
gdp_list_cntrys_with_subnat_data = unique(temp_gdp_list_cntrys_with_subnat_data);

clearvars temp_*

% clear countries to which regional data exist
gdp_cntry_all_cut = gdp_cntry_all;
for i = 1:size(gdp_list_cntrys_with_subnat_data,1)
    cntry_id = gdp_list_cntrys_with_subnat_data(i);
    
    gdp_cntry_all_cut(gdp_cntry_all_cut == cntry_id) = 0;
    
end

% clear national values where sub-national data exists
gdp_cntry_all_cut(gdp_subnat>0) = 0;


% % clear areas in reg data which are covered by country data
gdp_subnat_all_cut = gdp_subnat_all;
gdp_subnat_all_cut(gdp_cntry_all_cut > 0) = 0;


% make mask of allocated data

gdp_mask_all = gdp_cntry_all>0;

%imagesc(gdp_mask_all)

%% HDI

hdi_subnat_all = imread('/Volumes/Kummu_GIS/matlab/global_RBV/reg_hdi/temp/hdi_comb_al1.tif');
hdi_cntry_all = imread('/Volumes/Kummu_GIS/matlab/global_RBV/reg_hdi/temp/hdi_cntry_all1.tif');
%imagesc(hdi_cntry)
hdi_subnat = imread('/Volumes/Kummu_GIS/matlab/global_RBV/reg_hdi/temp/hdi_comb_nuts_other_nodata.tif');
hdi_cntry = geotiffread('/Volumes/Kummu_GIS/matlab/course_material/lecture1/adm0_NE_5m.tif');

% sea to zero
hdi_cntry_all(hdi_cntry_all == hdi_cntry_all(1,1)) = 0;
hdi_cntry(hdi_cntry_all == hdi_cntry_all(1,1)) = 0;

% remove antarctic
hdi_cntry_all(hdi_cntry_all == 30) = 0;
hdi_cntry(hdi_cntry == 30) = 0;

hdi_list_cntrys_with_subnat_data = xlsread('/Volumes/Kummu_GIS/matlab/global_RBV/socio_indicators_hdi_1990_2014.xlsx','sub_national_data','B1:B39');

clearvars temp_*

% clear countries to which regional data exist
hdi_cntry_all_cut = hdi_cntry_all;
for i = 1:size(hdi_list_cntrys_with_subnat_data,1)
    cntry_id = hdi_list_cntrys_with_subnat_data(i);
    
    hdi_cntry_all_cut(hdi_cntry_all_cut == cntry_id) = 0;
    
end

hdi_cntry_all_cut(hdi_subnat>0) = 0;

% clear areas in reg data which are covered by country data
hdi_subnat_all_cut = hdi_subnat_all;
hdi_subnat_all_cut(hdi_cntry_all_cut > 0) = 0;

% make mask of allocated data
hdi_mask_all = hdi_cntry_all>0;

%imagesc(hdi_mask_all)
%imagesc(hdi_cntry_all_cut)
%imagesc(hdi_cntry_all)
%% population 

% used here to ensure that the final land mask includes all the cells with
% population in both population datasets

load('/Volumes/Kummu_GIS/datasets/hyde_3_2/pop_hyde_32.mat');

pop_5arcmin = single(pop_hyde_32(:,:,21));
clearvars pop_h*

load gdp_total_30arcsec.mat

fun = @(block_struct) ...
   nansum(nansum(block_struct.data));
gdp_30arcsec_5arcmin = blockproc(gdp_total_30arcsec(:,:,3),[10 10],fun);

save gdp_hdi_pop_help.mat pop_5arcmin gdp_30arcsec_5arcmin

%% create land mask
load gdp_hdi_pop_help.mat
land = or(~isnan(pop_5arcmin), gdp_30arcsec_5arcmin > 0);
imagesc(land)

% include also areas with admin layer
land(or(gdp_cntry > 0, hdi_cntry > 0)) = 1;
land(or(gdp_subnat > 0, hdi_subnat > 0)) = 1;
imagesc(land)

% remove areas where no admin area included
land(gdp_mask_all == 0) = 0;
land(hdi_mask_all == 0) = 0;

imagesc(land)




%% save
save gdp_spatial_extent.mat gdp_cntry gdp_cntry_all gdp_cntry_all_cut gdp_subnat gdp_subnat_all_cut land

save hdi_spatial_extent.mat hdi_cntry hdi_cntry_all hdi_cntry_all_cut hdi_subnat hdi_subnat_all_cut land

%% prepare data for admin units

load gdp_spatial_extent.mat
load hdi_spatial_extent.mat

% GDP
temp_gdp_cntry = single(gdp_cntry_all_cut);
unique(temp_gdp_cntry);
temp_gdp_reg = single(gdp_subnat_all_cut);

temp_gdp_all = zeros(size(temp_gdp_reg),'single');
temp_gdp_all = temp_gdp_cntry;
temp_gdp_all(temp_gdp_cntry == 0) = 1000+temp_gdp_reg(temp_gdp_cntry == 0);

imagesc(temp_gdp_all);

% sea to NaN
temp_gdp_all(land == 0) = NaN;
imagesc(temp_gdp_all);
admin_areas_gdp = temp_gdp_all;

% HDI
temp_hdi_cntry = single(hdi_cntry_all_cut);
unique(temp_hdi_cntry);
temp_hdi_reg = single(hdi_subnat_all_cut);

%temp_hdi_all = zeros(size(temp_hdi_reg),'single');
temp_hdi_all = temp_hdi_cntry;
temp_hdi_all(temp_hdi_cntry == 0) = 1000+temp_hdi_reg(temp_hdi_cntry == 0);

imagesc(temp_hdi_all);

% sea to NaN
temp_hdi_all(land == 0) = NaN;
imagesc(temp_hdi_all);
admin_areas_hdi = temp_hdi_all;

% save
save admin_areas.mat admin_*


%% plot examples

% 
temp_gdp_cntry = single(gdp_cntry_all_cut);
temp_gdp_reg = single(gdp_subnat_all_cut);

temp_gdp_cntry(or(int16(land) == 0,temp_gdp_cntry==0)) = NaN;
temp_gdp_reg(or(int16(land) == 0,temp_gdp_reg==0)) = NaN;

imagesc(temp_gdp_reg);

% plot country
temp_colormap = flipud(cbrewer('div', 'BrBG',400));
temp_colormap(160:end,:) = [];
temp_plot = temp_gdp_cntry;
b = imagesc(temp_plot);
set(b,'AlphaData',~isnan(temp_plot))
colormap(temp_colormap)
set(gca, 'CLim', [0, nanmax(nanmax(temp_plot))],'xtick',[],'ytick',[],'dataAspectRatio',[1 1 1]);
colorbar;
clear temp_plot*

% plot sub-national
temp_colormap = flipud(cbrewer('div', 'BrBG',4000));
temp_colormap(1:2400,:) = [];
temp_plot = temp_gdp_reg;
b = imagesc(temp_plot);
set(b,'AlphaData',~isnan(temp_plot))
colormap(temp_colormap)
set(gca, 'CLim', [0, nanmax(nanmax(temp_plot))],'xtick',[],'ytick',[],'dataAspectRatio',[1 1 1]);
colorbar;
clear temp_plot*





