%% error estimates for subnational HDI data
% please note, you need to run first the sub_national_HDI_nov2017_v3.m, as
% some output from there is needed here

clc
clear
close all
    
cd /Volumes/Kummu_GIS/matlab/global_RBV/
addpath(genpath('/Volumes/Kummu_GIS/matlab/global_RBV/'));

%% SUB-NATIONAL
%% read sub-national data

% read subnational HDI dataset; in where subnationa HDI data is expressed
% as an anomaly to reported national level data
[~,~, raw_subnat] = xlsread('/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/sub_national_HDI_timeseries.xlsx'); %we only want the raw data

subnat_hdi_all = raw_subnat(2:end-2,3:end); %get rid of text rows and columns
subnat_hdi_all = cell2mat(subnat_hdi_all); %convert numbers stored as text to numeric data
clearvars temp_national_hdi

%% distance between reported data points

temp_subnat_hdi = subnat_hdi_all;
temp_subnat_hdi(temp_subnat_hdi>0) = 1;
temp_subnat_hdi(isnan(temp_subnat_hdi)) = 0;

% calculate distance of each data point to last data point with data

for i = 1:size(subnat_hdi_all,1)
    temp = temp_subnat_hdi(i,2:end); % select the HDI anomaly of subnational unit in question
    [r,c] = find(temp > 0); % detect non-zero cells
    
    temp2 = zeros(1,size(subnat_hdi_all,2)-1);
    temp2(:,max(c)) = 1;
    
    temp_dist = bwdist(temp2);
    
    subnat_last_value(i,:) = temp2;
    subnat_dist_last_value(i,:) = temp_dist;
    
end 

clear c i r temp*

%% subnat error

subnat_dist_error = zeros(size(subnat_hdi_all,1),2,2);

for i = 1:size(subnat_hdi_all,1)
    temp_hdi = subnat_hdi_all(i,2:end); % select the HDI anomaly of subnational unit in question
    temp_dist = subnat_dist_last_value(i,1:end); % select the distance data of subnational unit in question
    
    [r,c] = find(temp_hdi > 0); % detect non-zero cells
    
    temp_d = temp_dist(1,c(1,1:end-1)); % distance of the datapoints with HDI anomaly to the last reported value
    temp_value = temp_hdi(1,c(1,1:end-1)); % reported HDI anomaly of these data points
    
    temp_org_value = temp_hdi(1,c(1,end)); % value of the last reported datapoint
    
    temp_error = abs((temp_value-temp_org_value) ./ temp_org_value); % absolute difference between the HDI anomaly (except the last one) and the last reported value
    
    % store error
    subnat_dist_error(i,1:size(temp_error,2),1) = temp_error;
    % store distance
    subnat_dist_error(i,1:size(temp_error,2),2) = temp_d;
end

% to vector
temp1 = subnat_dist_error(:,:,1);
v_subnat_dist_error = temp1(:);

temp2 = subnat_dist_error(:,:,2);
v_subnat_dist_error(:,2) = temp2(:);

% clear zero rows
v_subnat_dist_error = v_subnat_dist_error(any(v_subnat_dist_error,2),:);

clear c i r temp*

% scatter plot
scatter(v_subnat_dist_error(:,2),v_subnat_dist_error(:,1));

% calculate mean and CI for each distance
temp_dist_u = unique(v_subnat_dist_error(:,2));

for i = 1:size(temp_dist_u)
    temp_u = temp_dist_u(i); % ID
    [c,r] = find(v_subnat_dist_error(:,2) == temp_u);
    temp_v = v_subnat_dist_error(c,1);
    
    temp_mean = nanmean(temp_v); % mean
    temp_pd = fitdist(temp_v,'Normal'); % fit propability distribution
    temp_ci = paramci(temp_pd); % confidence interval using pd
    
    % collect results
    subnat_CI(i+1,1) = temp_u;
    subnat_CI(i+1,2:4) = [temp_mean,temp_ci(:,1)'];

end

% fit curve to the points
f_mean=fit(subnat_CI(:,1),subnat_CI(:,2),'poly2');
plot(f_mean,subnat_CI(:,1),subnat_CI(:,2)) 
hold on
f_low=fit(subnat_CI(:,1),subnat_CI(:,3),'poly2');
plot(f_low,subnat_CI(:,1),subnat_CI(:,3))
hold on
f_high=fit(subnat_CI(:,1),subnat_CI(:,4),'poly2');
plot(f_high,subnat_CI(:,1),subnat_CI(:,4))

temp_alldist = [1:26];
temp_value_alldist(1,:) = f_high(temp_alldist);
temp_value_alldist(2,:) = f_mean(temp_alldist);
temp_value_alldist(3,:) = f_low(temp_alldist);

clear c i r temp*

%% error in each sub-national unit

% read sub-national data
subnat_hdi = xlsread('/Users/mkummu/Documents/work/publications/varis_al_global_RBV/hdi/adm1_gis_layer_v3_to_qgis.xlsx','adm1_gis_layer_v3','A2:J568');

% we needed to modify the id in GIS analysis; here 1000 added
subnat_hdi(:,1) = 1000 + subnat_hdi(:,1);

% read nuts (EU)
nuts_hdi = xlsread('/Users/mkummu/Documents/work/publications/varis_al_global_RBV/hdi/nuts2_hdi_matlab.xlsx','nuts2_HDI','C2:G361');

% error distance

error_subnat = [nuts_hdi(:,2);subnat_hdi(:,1)]; % IDs
error_subnat(:,2) = [nuts_hdi(:,end);subnat_hdi(:,end)]; % year of data

error_subnat(:,3:28) = 0; % zero matrix

for i = 1:size(error_subnat,1)
    temp = error_subnat(i,:,1);
    
    temp_yr = temp(1,2); % collect data year
    temp_c = temp_yr-1987; % turn year to simpler index
    
    temp(1,temp_c) = 1;
    temp_dist = bwdist(temp(1,3:end)); % distance to datapoint
    
    % place of value
    error_subnat(i,temp_c) = 1; 
    % distance to closest value
    error_subnat(i,3:end,2) = temp_dist;
    % mean error
    error_subnat(i,3:end,3) = f_mean(temp_dist);   
end

% negative values to zero
error_subnat(error_subnat<0) = 0;

clear c i r temp*
%% to map

load hdi_spatial_extent.mat

% NUTS (all values less than 1000)
temp_macroreg_hdi = hdi_reg_all_cut;
temp_macroreg_hdi(temp_macroreg_hdi>1000) = 0;

M_nuts_id = temp_macroreg_hdi;

% other areas (all values more than 1000)
temp_macroreg_hdi = hdi_reg_all_cut;
temp_macroreg_hdi(temp_macroreg_hdi<1000) = 0;

M_subnat_id = temp_macroreg_hdi;

clearvars temp_hdi hdi_cntry*

% 

M_subnat_error = zeros(size(M_nuts_id,1),size(M_nuts_id,2),26,'single');
%M_reg_error = zeros(size(M_nuts_id),'single');

for i = 1:size(error_subnat,1)
    temp_id = error_subnat(i,1,1);
    
    if temp_id < 1000
        temp_mask = M_nuts_id == temp_id;       
        parfor yr = 1:26
            temp_error = zeros(size(M_nuts_id));
            temp_error(temp_mask) = error_subnat(i,yr+2,3);
            M_subnat_error(:,:,yr) = M_subnat_error(:,:,yr) + temp_error;
        end
        
    else
        temp_mask = M_subnat_id == temp_id;     
        parfor yr = 1:26
            temp_error = zeros(size(M_subnat_id));
            temp_error(temp_mask) = error_subnat(i,yr+2,3);
            M_subnat_error(:,:,yr) = M_subnat_error(:,:,yr) + temp_error;
        end
    end   
    X = ['Current round: ',num2str(i),'.'];
    disp(X)
end
imagesc(M_subnat_error(:,:,1));

clearvars *_id i hdi_reg* f_* reg_* nuts_* temp*

save hdi_subnat_error.mat M_subnat_error

%% error estimate for national data

%% read country data

% fao_id - compatible with the adm0_5min 
% HDI - human development index - the higher the better

[~,~, raw_country] = xlsread('/Volumes/Kummu_GIS/matlab/global_RBV/socio_indicators_hdi_1990_2015.xlsx','HDI_to_matlab'); %we only want the raw data

national_hdi_all = raw_country(2:end,3:end); %get rid of text rows and columns
national_hdi = cell2mat(national_hdi_all); %convert numbers stored as text to numeric data
clearvars temp_national_hdi

national_hdi(national_hdi == 0) = NaN;

clearvars temp* raw*


%% select countries with full data

for i = 1:size(national_hdi,1)
    temp = national_hdi(i,3:end);
    temp_hdi_count(i,1) = sum(temp(:) > 0);
end

[row,col] = find(temp_hdi_count == nanmax(temp_hdi_count));

national_hdi_fulldata = national_hdi(row,:);


clearvars temp* row col



%% macro-regional values
% go through the years where data is available

macroreg_hdi = unique(national_hdi(:,2));

% average regional value from national data

for i = 1:size(national_hdi_fulldata,2)-2
    
    temp = accumarray(national_hdi_fulldata(:,2),national_hdi_fulldata(:,i+2),[],@nanmean);
    macroreg_hdi(1:12,i+1) = temp(:,1);
    
end

% no data to NaN
macroreg_hdi(macroreg_hdi == 0) = NaN;


% regional average when specific country is left out (we compared the national value to a regional average without the data from that specific country)

macroreg_hdi_leaveout = zeros(size(macroreg_hdi,1),size(national_hdi_fulldata,2)-1,size(national_hdi_fulldata,1));
macroreg_hdi_leaveout(:,1,:) = repmat(macroreg_hdi(:,1),1,1,size(national_hdi_fulldata,1));

for cntry = 1:size(national_hdi_fulldata,1)
    for i = 1:size(national_hdi_fulldata,2)-2
        temp_data = national_hdi_fulldata([1:cntry-1 cntry+1:end],:); % leave out the country in question
        temp = accumarray(temp_data(:,2),temp_data(:,i+2),[],@nanmean);
        macroreg_hdi_leaveout(1:12,i+1,cntry) = temp(:,1);
        
    end
    
end

% no data to NaN
macroreg_hdi_leaveout(macroreg_hdi_leaveout == 0) = NaN;

clearvars temp*
clearvars i j 


%% error in extrapolation - using leaveout method
% note: in HDI no interpolation was needed, and thus only extrapolation
% error is needed to analyse

% define how many 'rounds' (i.e. max distance to closest value)
n = 23;

national_hdi_extrapol_lo = zeros(size(national_hdi_fulldata));
national_hdi_extrapol_lo(:,1:2) = national_hdi_fulldata(:,1:2);

national_hdi_extrapol_lo = repmat(national_hdi_extrapol_lo,1,1,n);

% next lines estimate the HDI with the use of regional trend, using the
% last reported national level HDI as a starting point. 

for n_start = 1:n
    national_hdi_extrapol_start = zeros(1,size(national_hdi_fulldata,2));
    national_hdi_extrapol_start(1,3:2+n_start) = -1;
    
    % the first years
    for i = 1:size(national_hdi_fulldata,1)
        temp_macroreg_area = national_hdi_fulldata(i,2); % macro-region ID
        temp_cntry_row = i;
        
        [row,col] = find(fliplr(national_hdi_extrapol_start(1,3:end) == -1)); % identify the cells that were extrapolated
        
        
        
        if isempty(col) % in case no need to extrapolate
            
        elseif size(col,2) == 26 % in case no data at all
            
            
        else
            
            [row_macroreg,col_macroreg] = find(macroreg_hdi_leaveout(:,1,temp_cntry_row) == temp_macroreg_area);
            
            % flip
            temp_macroreg_hdi = fliplr(macroreg_hdi_leaveout(row_macroreg,2:end,temp_cntry_row)); % find the correct macro-regional value           
            temp_macroreg_hdi = temp_macroreg_hdi(1,(col(1,1)-1:end));
                        
            temp_nat_hdi = fliplr(national_hdi_fulldata(i,3:end));
            
            temp_nat_final_entry = temp_nat_hdi(1,col(1,1)-1);
            temp_diff = temp_nat_final_entry ./ temp_macroreg_hdi(1,1); % ratio between macro-regions value and last reported national value
            
            % scale based on macro-regions value
            temp_national_hdi_2015 = temp_diff .* temp_macroreg_hdi(1,2:end);

            % fill the matrix
            national_hdi_extrapol_lo(i,3:3+size(col,2)-1,n_start) = fliplr(temp_national_hdi_2015);
        end
    end
end
clearvars temp* i k col* row* 



%% calculate error
national_hdi_extrapol_error_lo = zeros(size(national_hdi_extrapol_lo));


for n_start = 1:n
    national_hdi_extrapol_error_lo(:,3:2+n_start,n_start) = abs(national_hdi_fulldata(:,3:2+n_start) - national_hdi_extrapol_lo(:,3:2+n_start,n_start)); % difference between the reported data and value calculated with regional trends
end

% normalise the error
national_hdi_extrapol_error_norm_lo = national_hdi_extrapol_error_lo ./ repmat(national_hdi_fulldata,1,1,n);
national_hdi_extrapol_error_norm_lo(national_hdi_extrapol_error_norm_lo==0) = NaN;

for i = 1:size(national_hdi_extrapol_error_norm_lo,3)
    temp = national_hdi_extrapol_error_norm_lo(:,3:2+i,i);
    
    temp_collect(:,1:i,i) = fliplr( temp);    
end


for i = 1:size(temp_collect,2)
    temp = temp_collect(:,i,:);
    hdi_extr_error_collect_lo(:,i) = temp(:);
    
end

hdi_extr_error_collect_lo(hdi_extr_error_collect_lo == 0) = NaN; % zero values to NaN

% mean
global_hdi_ext_error_norm_mean_lo = (squeeze( nanmean(hdi_extr_error_collect_lo,1)));

for i = 1:size(hdi_extr_error_collect_lo,2)
    temp_pd = fitdist(hdi_extr_error_collect_lo(:,i),'Normal'); %fit propability distribution
    temp_ci = paramci(temp_pd);  % confidence interval using pd
    global_hdi_extr_error_norm_ci_lo(:,i) = temp_ci(:,1); % collect results
end

% plot
fig_hdi_ext = figure;

confplot(1:size(global_hdi_ext_error_norm_mean_lo,2),global_hdi_ext_error_norm_mean_lo,global_hdi_ext_error_norm_mean_lo-global_hdi_extr_error_norm_ci_lo(1,:),global_hdi_extr_error_norm_ci_lo(2,:)-global_hdi_ext_error_norm_mean_lo); 


saveas(fig_hdi_ext,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_fig_error_hdi_ext.eps','epsc');


%% distance to error
% the distance to closest value in HDI dataset are now transferred to error
% using the data calculated above

load hdi_distance_to_closest_value.mat % the distance to closest value in HDI dataset was calculated in sub_national_HDI_nov2017_v3.m

load('hdi_spatial_extent.mat','land');

M_ext_maxdist = nanmax(M_extrap_dist,[],3);
M_ext_maxerror = zeros(size(M_ext_maxdist),'single');

for i = 1:size(global_hdi_ext_error_norm_mean_lo,2)
    temp_error = global_hdi_ext_error_norm_mean_lo(1,i);
    temp_mask = M_ext_maxdist == i;
    M_ext_maxerror(temp_mask) = temp_error;    
end

sea = land == 0;


% West Sahara - no data and error to 0.25
load('hdi_spatial_extent.mat','hdi_cntry');
M_ext_maxerror(hdi_cntry == 205) = 0.25;

%% combine national and sub-national errors
load hdi_subnat_error.mat

M_subnat_maxerror = nanmax(M_subnat_error,[],3);

% sea to NaN
sea = land == 0;
M_ext_maxerror(sea) = NaN;
M_subnat_maxerror(sea) = NaN;

% combine
M_ext_subnat_nat_error = M_ext_maxerror + M_subnat_maxerror;

% no error to negative
M_ext_subnat_nat_error(M_ext_subnat_nat_error == 0) = -1;

save M_HDI_subnat_error.mat M_*

%% plot max error


R_00833 = georasterref('RasterSize', [2160 4320], ...
      'RasterInterpretation', 'cells', 'ColumnsStartFrom', 'north', ...
      'LatitudeLimits', [-90 90], 'LongitudeLimits', [-180 180]);

temp_colormap(2:21,:) = cbrewer('seq', 'YlOrRd',20);
temp_colormap(1,:) = [211/255,211/255,211/255];

figure_error_map = figure('pos',[10 10 1500 1000]);


temp_plot = M_ext_subnat_nat_error;

axesm ('robinson', 'Frame', 'off', 'Grid', 'off','MapLatLimit',[-90 90]);
set(gca,'CLim', [-0.3/20, 0.3],'xcolor','w','ycolor','w','xtick',[],'ytick',[], 'dataAspectRatio',[1 1 1])
geoshow(temp_plot, R_00833, 'DisplayType', 'surface');  

colormap(temp_colormap)
colorbar;

clear temp_plot*

title('Max error in HDI extrapolation');

saveas(figure_error_map,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_error_hdi_subnat_nat_map_v6.tif','tif'); 
saveas(figure_error_map,'/Users/mkummu/Documents/work/publications/kummu&al_gdp_hdi_datasets/figures/raw_error_hdi_subnat_nat_map_v6.eps','epsc');
